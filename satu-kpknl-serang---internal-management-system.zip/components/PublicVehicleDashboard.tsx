
import React, { useState } from 'react';
import { Truck, Car, AlertCircle, Info, ArrowRight, Clock, User, Briefcase, Calendar, X, Check, MapPin } from 'lucide-react';
import { VehicleStatus, VehicleType, Vehicle } from '../types';

const INITIAL_VEHICLES: Vehicle[] = [
  { id: '1', name: 'Toyota Innova Reborn', plateNumber: 'A 1234 XX', status: VehicleStatus.AVAILABLE, type: VehicleType.CAR, category: 'OPERATIONAL', photo: 'https://images.unsplash.com/photo-1590362891991-f776e747a588?auto=format&fit=crop&q=80&w=600' },
  { id: '2', name: 'Toyota Hiace Commuter', plateNumber: 'A 5678 YY', status: VehicleStatus.BORROWED, type: VehicleType.CAR, category: 'OPERATIONAL', photo: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80&w=600', borrower: 'Ahmad Faisal', section: 'Seksi HI', purpose: 'Sosialisasi PKN', timeRange: '08:00 - 14:00' },
  { id: '3', name: 'Toyota Fortuner', plateNumber: 'A 1 RI', status: VehicleStatus.AVAILABLE, type: VehicleType.CAR, category: 'HEAD_OFFICE', photo: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=600' },
  { id: '4', name: 'Isuzu Elf Logistik', plateNumber: 'A 9012 ZZ', status: VehicleStatus.MAINTENANCE, type: VehicleType.TRUCK, category: 'OPERATIONAL', photo: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&q=80&w=600' },
];

const PublicVehicleDashboard: React.FC = () => {
  const [vehicles, setVehicles] = useState(INITIAL_VEHICLES);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [isReturnModalOpen, setIsReturnModalOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', section: '', purpose: '', startTime: '', endTime: '' });

  const handleOpenBooking = (v: Vehicle) => {
    setSelectedVehicle(v);
    setIsBookingModalOpen(true);
  };

  const handleOpenReturn = (v: Vehicle) => {
    setSelectedVehicle(v);
    setIsReturnModalOpen(true);
  };

  const submitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    setVehicles(prev => prev.map(v => 
      v.id === selectedVehicle?.id 
        ? { ...v, status: VehicleStatus.BORROWED, borrower: formData.name, section: formData.section, purpose: formData.purpose, timeRange: `${formData.startTime} - ${formData.endTime}` } 
        : v
    ));
    setIsBookingModalOpen(false);
    setFormData({ name: '', section: '', purpose: '', startTime: '', endTime: '' });
    alert("Permohonan Peminjaman Berhasil Dikirim!");
  };

  const handleReturnAction = (toNext: boolean) => {
    setVehicles(prev => prev.map(v => 
      v.id === selectedVehicle?.id 
        ? { ...v, status: toNext ? VehicleStatus.BORROWED : VehicleStatus.AVAILABLE, borrower: toNext ? 'Peminjam Antrian Berikutnya' : undefined, section: undefined, purpose: undefined, timeRange: undefined } 
        : v
    ));
    setIsReturnModalOpen(false);
    alert(toNext ? "Kendaraan diteruskan ke booking selanjutnya." : "Kendaraan kini tersedia kembali untuk umum.");
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-700">
      <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 to-blue-900 p-8 md:p-12 rounded-[2.5rem] text-white shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-blue-500/20 rounded-full blur-3xl"></div>
        <div className="relative z-10 space-y-4">
          <h2 className="text-3xl md:text-5xl font-black tracking-tighter leading-tight italic">Dashboard Armada</h2>
          <p className="text-blue-100 text-lg max-w-xl font-medium">Monitoring ketersediaan kendaraan dinas KPKNL Serang secara real-time.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {vehicles.map((v) => (
          <div key={v.id} className="group bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden hover:shadow-2xl transition-all flex flex-col">
            <div className="relative h-56 overflow-hidden">
              <img src={v.photo} alt={v.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
              <div className="absolute top-4 right-4">
                <span className={`text-[10px] font-black px-4 py-2 rounded-full border-2 bg-white/90 backdrop-blur shadow-lg ${
                  v.status === VehicleStatus.AVAILABLE ? 'border-emerald-500 text-emerald-600' :
                  v.status === VehicleStatus.BORROWED ? 'border-rose-500 text-rose-600' : 'border-amber-500 text-amber-600'
                }`}>
                  {v.status}
                </span>
              </div>
              <div className="absolute bottom-4 left-6">
                 <p className="text-white font-black text-xl italic tracking-tighter">{v.name}</p>
                 <p className="text-white/70 text-[10px] font-bold uppercase tracking-widest">{v.plateNumber}</p>
              </div>
            </div>

            <div className="p-6 flex-1 flex flex-col space-y-4">
              {v.status === VehicleStatus.BORROWED && (
                <div className="space-y-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="flex items-center gap-2 text-rose-600">
                    <User className="w-4 h-4" />
                    <span className="text-xs font-black uppercase tracking-tight">{v.borrower}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500">
                    <Clock className="w-4 h-4" />
                    <span className="text-[10px] font-bold">{v.timeRange || 'Jam Tidak Ditentukan'}</span>
                  </div>
                </div>
              )}

              {v.category === 'HEAD_OFFICE' && (
                <div className="flex items-center gap-2 px-3 py-2 bg-amber-50 text-amber-700 rounded-xl border border-amber-100">
                  <Info className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Hanya Kepala Kantor</span>
                </div>
              )}

              <div className="mt-auto pt-4 flex flex-col gap-3">
                {v.status === VehicleStatus.AVAILABLE ? (
                  <button 
                    onClick={() => handleOpenBooking(v)}
                    disabled={v.category === 'HEAD_OFFICE'}
                    className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-xl shadow-blue-500/20 disabled:opacity-30"
                  >
                    Pinjam Sekarang <ArrowRight className="w-4 h-4" />
                  </button>
                ) : v.status === VehicleStatus.BORROWED ? (
                  <>
                    <button 
                      onClick={() => handleOpenBooking(v)}
                      className="w-full py-4 bg-white border-2 border-slate-200 text-slate-600 rounded-2xl font-black text-xs uppercase tracking-widest hover:border-blue-600 hover:text-blue-600 transition-all"
                    >
                      Ajukan Booking
                    </button>
                    <button 
                      onClick={() => handleOpenReturn(v)}
                      className="w-full py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-black transition-all"
                    >
                      Kembalikan Unit
                    </button>
                  </>
                ) : (
                  <div className="py-4 bg-slate-100 text-slate-400 rounded-2xl text-center text-[10px] font-black uppercase tracking-widest">
                    Dalam Perbaikan
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Booking Modal */}
      {isBookingModalOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-10 bg-gradient-to-br from-blue-600 to-indigo-700 text-white relative">
              <button onClick={() => setIsBookingModalOpen(false)} className="absolute top-6 right-6 p-2 bg-white/10 rounded-full hover:bg-white/20 transition-all"><X className="w-5 h-5" /></button>
              <h3 className="text-3xl font-black italic tracking-tighter">Form Peminjaman</h3>
              <p className="text-blue-100 text-sm font-bold uppercase tracking-widest mt-2">{selectedVehicle?.name} - {selectedVehicle?.plateNumber}</p>
            </div>
            <form onSubmit={submitBooking} className="p-10 space-y-6 bg-white">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nama Peminjam</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                    <input required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Seksi / Unit</label>
                  <div className="relative">
                    <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                    <input required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.section} onChange={e => setFormData({...formData, section: e.target.value})} />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Tujuan Peminjaman</label>
                <textarea required className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold min-h-[100px]" value={formData.purpose} onChange={e => setFormData({...formData, purpose: e.target.value})} placeholder="Contoh: Perjalanan Dinas ke Jakarta..." />
              </div>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Pinjam Dari Jam</label>
                  <div className="relative">
                    <Clock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                    <input type="time" required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.startTime} onChange={e => setFormData({...formData, startTime: e.target.value})} />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Sampai Jam</label>
                  <div className="relative">
                    <Clock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                    <input type="time" required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.endTime} onChange={e => setFormData({...formData, endTime: e.target.value})} />
                  </div>
                </div>
              </div>
              <button type="submit" className="w-full py-5 bg-blue-600 text-white rounded-[2rem] font-black text-sm uppercase tracking-widest shadow-2xl shadow-blue-500/40 hover:bg-blue-700 transition-all active:scale-95">
                {selectedVehicle?.status === VehicleStatus.BORROWED ? 'Konfirmasi Antrian Booking' : 'Konfirmasi Peminjaman'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Return Modal */}
      {isReturnModalOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-[3rem] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-8 duration-500">
            <div className="p-12 text-center space-y-6">
              <div className="w-24 h-24 bg-emerald-100 rounded-[2.5rem] flex items-center justify-center mx-auto mb-4 border-4 border-white shadow-xl">
                <Check className="w-12 h-12 text-emerald-600" />
              </div>
              <div>
                <h3 className="text-3xl font-black text-slate-900 tracking-tighter italic">Selesai Memakai?</h3>
                <p className="text-slate-500 text-sm font-medium mt-2 leading-relaxed">Pilih tindakan pengembalian untuk unit <span className="font-black text-slate-800">{selectedVehicle?.name}</span></p>
              </div>
              
              <div className="grid grid-cols-1 gap-4 pt-4">
                <button 
                  onClick={() => handleReturnAction(true)}
                  className="group flex items-center justify-between p-6 bg-blue-600 text-white rounded-[2rem] text-left hover:bg-blue-700 transition-all"
                >
                  <div className="space-y-1">
                    <p className="font-black text-lg italic tracking-tight">Teruskan Booking</p>
                    <p className="text-blue-100 text-[10px] font-bold uppercase tracking-widest">Serahkan ke peminjam berikutnya</p>
                  </div>
                  <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
                </button>
                <button 
                  onClick={() => handleReturnAction(false)}
                  className="group flex items-center justify-between p-6 bg-slate-100 text-slate-800 rounded-[2rem] text-left hover:bg-slate-200 transition-all border-2 border-transparent hover:border-slate-300"
                >
                  <div className="space-y-1">
                    <p className="font-black text-lg italic tracking-tight">Kembali ke Umum</p>
                    <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Status kendaraan jadi tersedia</p>
                  </div>
                  <Check className="w-6 h-6 text-emerald-600" />
                </button>
              </div>

              <button 
                onClick={() => setIsReturnModalOpen(false)}
                className="text-xs font-black text-slate-400 uppercase tracking-widest hover:text-slate-600 transition-all pt-4"
              >
                Batalkan Pengembalian
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PublicVehicleDashboard;
