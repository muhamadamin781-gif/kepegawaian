
import React from 'react';
import { Search, Filter, Shield, AlertCircle, CheckCircle2, ChevronDown } from 'lucide-react';

const AuditHistory: React.FC = () => {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Security Audit Trail</h2>
          <p className="text-sm text-slate-500">Log perubahan data dan aktivitas sistem yang tidak dapat dihapus</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl flex items-center gap-4">
          <div className="p-3 bg-emerald-600 rounded-xl text-white">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-emerald-600 uppercase">Status Sistem</p>
            <p className="text-lg font-bold text-emerald-900 leading-tight">Berjalan Normal</p>
          </div>
        </div>
        <div className="bg-blue-50 border border-blue-100 p-4 rounded-2xl flex items-center gap-4">
          <div className="p-3 bg-blue-600 rounded-xl text-white">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-blue-600 uppercase">Enkripsi Data</p>
            <p className="text-lg font-bold text-blue-900 leading-tight">Aktif (AES-256)</p>
          </div>
        </div>
        <div className="bg-amber-50 border border-amber-100 p-4 rounded-2xl flex items-center gap-4">
          <div className="p-3 bg-amber-500 rounded-xl text-white">
            <AlertCircle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-amber-600 uppercase">Pending Review</p>
            <p className="text-lg font-bold text-amber-900 leading-tight">2 Temuan Baru</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h3 className="font-bold text-slate-800">Riwayat Kejadian</h3>
            <div className="h-4 w-px bg-slate-200"></div>
            <span className="text-xs font-medium text-slate-500">2,485 entries found</span>
          </div>
          <button className="flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-blue-600">
            Last 24 Hours <ChevronDown className="w-4 h-4" />
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {[
            { action: 'UPDATE_LOG', user: 'Admin Vanguard', target: 'B 1234 XYZ', time: 'Today, 11:30', impact: 'MEDIUM' },
            { action: 'NEW_PRESENCE', user: 'System (Auto)', target: 'Ahmad Faisal', time: 'Today, 11:15', impact: 'LOW' },
            { action: 'LOGIN_SUCCESS', user: 'Security Team A', target: 'Terminal 01', time: 'Today, 07:00', impact: 'LOW' },
            { action: 'EXPORT_REPORT', user: 'Supervisor', target: 'Monthly_Sept.xlsx', time: 'Yesterday, 16:45', impact: 'MEDIUM' },
            { action: 'PERMISSION_CHANGE', user: 'Super Admin', target: 'User Role: Budi', time: 'Yesterday, 09:20', impact: 'HIGH' },
          ].map((item, idx) => (
            <div key={idx} className="p-4 md:px-6 md:py-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50 transition-colors">
              <div className="flex items-start gap-4">
                <div className={`mt-1 w-2 h-2 rounded-full shrink-0 ${
                  item.impact === 'HIGH' ? 'bg-rose-500' : 
                  item.impact === 'MEDIUM' ? 'bg-amber-500' : 'bg-emerald-500'
                }`}></div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-slate-800 tracking-wider">{item.action}</span>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-500">ID: AUD-992{idx}</span>
                  </div>
                  <p className="text-sm text-slate-600 mt-1">
                    <span className="font-bold text-slate-900">{item.user}</span> memproses <span className="font-bold text-slate-900">{item.target}</span>
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-between md:justify-end gap-6">
                <div className="text-right">
                  <p className="text-xs font-bold text-slate-800">{item.time}</p>
                  <p className="text-[10px] text-slate-400 font-medium">Verified by Blockchain</p>
                </div>
                <button className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all">
                  <Filter className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-center">
          <button className="text-sm font-bold text-blue-600 hover:underline">Tampilkan 50 baris lainnya</button>
        </div>
      </div>
    </div>
  );
};

export default AuditHistory;
