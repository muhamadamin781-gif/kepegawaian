
import React, { useState } from 'react';
import { 
  Package, 
  Wrench, 
  Plus, 
  Search, 
  ChevronRight, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  ClipboardList,
  Filter,
  MoreVertical,
  Box,
  Truck,
  Zap,
  Droplets,
  Wind,
  Monitor,
  Edit3,
  Trash2,
  Smartphone,
  X,
  User,
  Hash
} from 'lucide-react';
import { ElectronicItem } from '../types';

interface HouseholdModuleProps {
  items: ElectronicItem[];
  onUpdateItems: (items: ElectronicItem[]) => void;
}

const HouseholdModule: React.FC<HouseholdModuleProps> = ({ items, onUpdateItems }) => {
  const [activeTab, setActiveTab] = useState<'inventory' | 'tickets' | 'electronics' | 'proposals'>('inventory');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ElectronicItem | null>(null);
  const [formData, setFormData] = useState<Partial<ElectronicItem>>({
    itemName: '', itemCode: '', quantity: 1, personName: '', section: ''
  });

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({ itemName: '', itemCode: '', quantity: 1, personName: '', section: '' });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: ElectronicItem) => {
    setEditingItem(item);
    setFormData({ ...item });
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("Hapus data aset elektronik ini?")) {
      onUpdateItems(items.filter(i => i.id !== id));
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingItem) {
      onUpdateItems(items.map(i => i.id === editingItem.id ? { ...i, ...formData } as ElectronicItem : i));
    } else {
      const newItem = { ...formData, id: Math.random().toString(36).substr(2, 9) } as ElectronicItem;
      onUpdateItems([...items, newItem]);
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
      {/* Header & Stats */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tighter italic">Rumah Tangga</h2>
          <p className="text-slate-500 font-medium mt-1">Manajemen Sarpras, Inventaris & Layanan Umum Kantor</p>
        </div>
        <div className="flex gap-3">
          <button className="px-6 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-black uppercase tracking-widest text-slate-600 hover:bg-slate-50 transition-all flex items-center gap-2">
            <Filter className="w-4 h-4" /> Filter Data
          </button>
          {activeTab === 'electronics' && (
            <button 
              onClick={handleOpenAdd}
              className="px-8 py-3 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center gap-2"
            >
              <Plus className="w-5 h-5" /> Tambah Aset Elektronik
            </button>
          )}
          {activeTab !== 'electronics' && (
            <button className="px-8 py-3 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center gap-2">
              <Plus className="w-5 h-5" /> Tambah Data
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-amber-50 border border-amber-100 p-6 rounded-[2.5rem] flex items-center gap-5">
           <div className="w-14 h-14 bg-amber-500 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/20">
              <AlertTriangle className="w-7 h-7" />
           </div>
           <div>
              <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest">Low Stock Alert</p>
              <h4 className="text-2xl font-black text-amber-900 italic">5 Item</h4>
           </div>
        </div>
        <div className="bg-blue-50 border border-blue-100 p-6 rounded-[2.5rem] flex items-center gap-5">
           <div className="w-14 h-14 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Monitor className="w-7 h-7" />
           </div>
           <div>
              <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Total Elektronik</p>
              <h4 className="text-2xl font-black text-blue-900 italic">{items.length} Unit</h4>
           </div>
        </div>
        <div className="bg-slate-900 p-6 rounded-[2.5rem] flex items-center gap-5 text-white">
           <div className="w-14 h-14 bg-white/10 text-white rounded-2xl flex items-center justify-center backdrop-blur">
              <ClipboardList className="w-7 h-7" />
           </div>
           <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Usulan Baru</p>
              <h4 className="text-2xl font-black italic text-white">12 Berkas</h4>
           </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="flex flex-wrap gap-4 p-2 bg-white border border-slate-200 rounded-[2rem] w-fit">
        <button 
          onClick={() => setActiveTab('inventory')}
          className={`px-8 py-3 rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'inventory' ? 'bg-slate-900 text-white shadow-lg shadow-slate-900/10' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <Box className="w-4 h-4" /> Stok ATK & Sarana
        </button>
        <button 
          onClick={() => setActiveTab('electronics')}
          className={`px-8 py-3 rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'electronics' ? 'bg-slate-900 text-white shadow-lg shadow-slate-900/10' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <Smartphone className="w-4 h-4" /> Monitoring Elektronik
        </button>
        <button 
          onClick={() => setActiveTab('tickets')}
          className={`px-8 py-3 rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'tickets' ? 'bg-slate-900 text-white shadow-lg shadow-slate-900/10' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <Wrench className="w-4 h-4" /> Service Tiket
        </button>
        <button 
          onClick={() => setActiveTab('proposals')}
          className={`px-8 py-3 rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'proposals' ? 'bg-slate-900 text-white shadow-lg shadow-slate-900/10' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <ClipboardList className="w-4 h-4" /> Review Usulan
        </button>
      </div>

      {/* Content Area */}
      {activeTab === 'electronics' && (
        <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-500">
          <div className="p-8 border-b border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6 bg-slate-50/30">
             <div className="relative w-full md:w-96">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="text" placeholder="Cari Kode atau Nama Aset..." className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl outline-none focus:border-blue-500 text-xs font-bold" />
             </div>
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">Sinkronisasi Otomatis: Aktif</p>
          </div>
          <div className="overflow-x-auto">
             <table className="w-full text-left">
               <thead>
                 <tr className="bg-slate-50 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
                   <th className="px-10 py-6">Informasi Barang</th>
                   <th className="px-10 py-6">Kode Aset</th>
                   <th className="px-10 py-6 text-center">Jumlah</th>
                   <th className="px-10 py-6">Penanggung Jawab</th>
                   <th className="px-10 py-6 text-right">Tindakan</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                 {items.length > 0 ? items.map((item) => (
                   <tr key={item.id} className="hover:bg-slate-50/50 transition-all group">
                     <td className="px-10 py-6">
                        <div className="flex items-center gap-4">
                           <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                              <Smartphone className="w-5 h-5" />
                           </div>
                           <p className="text-sm font-black text-slate-900 italic">{item.itemName}</p>
                        </div>
                     </td>
                     <td className="px-10 py-6">
                        <span className="text-[10px] font-bold text-slate-400 uppercase">{item.itemCode}</span>
                     </td>
                     <td className="px-10 py-6 text-center">
                        <span className="text-sm font-black text-blue-600">{item.quantity} Unit</span>
                     </td>
                     <td className="px-10 py-6">
                        <p className="text-sm font-black text-slate-900">{item.personName}</p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.section}</p>
                     </td>
                     <td className="px-10 py-6 text-right">
                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                           <button 
                             onClick={() => handleOpenEdit(item)}
                             className="p-2.5 text-slate-400 hover:text-blue-600 hover:bg-white rounded-xl transition-all border border-transparent hover:border-slate-100"
                           >
                             <Edit3 className="w-4 h-4" />
                           </button>
                           <button 
                             onClick={() => handleDelete(item.id)}
                             className="p-2.5 text-slate-400 hover:text-rose-600 hover:bg-white rounded-xl transition-all border border-transparent hover:border-slate-100"
                           >
                             <Trash2 className="w-4 h-4" />
                           </button>
                        </div>
                     </td>
                   </tr>
                 )) : (
                   <tr>
                     <td colSpan={5} className="px-10 py-20 text-center">
                        <Monitor className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                        <p className="text-slate-400 font-black uppercase tracking-widest text-xs">Belum ada data elektronik</p>
                     </td>
                   </tr>
                 )}
               </tbody>
             </table>
          </div>
        </div>
      )}

      {/* Inventory & Others Placeholder */}
      {activeTab === 'inventory' && (
        <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/30">
             <div className="relative w-full md:w-96">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="text" placeholder="Cari Item Inventaris..." className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl outline-none focus:border-blue-500 text-xs font-bold" />
             </div>
             <button className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline">Download Stock Opname</button>
          </div>
          <div className="p-20 text-center">
            <p className="text-slate-300 font-black uppercase tracking-widest text-xs">Modul ATK & Persediaan Kantor</p>
          </div>
        </div>
      )}

      {/* Modal CRUD Monitoring Elektronik */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-8 bg-slate-900 text-white flex justify-between items-center">
               <div>
                  <h3 className="text-2xl font-black italic tracking-tighter">{editingItem ? 'Edit Data Elektronik' : 'Tambah Aset Baru'}</h3>
                  <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-1">Satu KPKNL Serang Monitoring System</p>
               </div>
               <button onClick={() => setIsModalOpen(false)} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-all"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSave} className="p-10 space-y-6">
               <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nama Barang Elektronik</label>
                  <div className="relative">
                    <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                    <input required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.itemName} onChange={e => setFormData({...formData, itemName: e.target.value})} placeholder="Contoh: Laptop HP ProBook 440..." />
                  </div>
               </div>

               <div className="grid grid-cols-2 gap-6">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Kode Barang / NUP</label>
                    <div className="relative">
                      <Hash className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                      <input required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.itemCode} onChange={e => setFormData({...formData, itemCode: e.target.value})} placeholder="EL-000..." />
                    </div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Jumlah Unit</label>
                    <input type="number" required className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.quantity} onChange={e => setFormData({...formData, quantity: parseInt(e.target.value) || 0})} />
                 </div>
               </div>

               <div className="grid grid-cols-2 gap-6">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nama Pemakai</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                      <input required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.personName} onChange={e => setFormData({...formData, personName: e.target.value})} placeholder="Nama Pegawai..." />
                    </div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Seksi / Unit Kerja</label>
                    <input required className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.section} onChange={e => setFormData({...formData, section: e.target.value})} placeholder="Seksi HI / Lelang / dsb..." />
                 </div>
               </div>

               <div className="pt-6 border-t border-slate-100 flex gap-4">
                  <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-5 bg-slate-100 text-slate-400 rounded-[2rem] font-black text-[10px] uppercase tracking-widest hover:bg-slate-200 transition-all">Batalkan</button>
                  <button type="submit" className="flex-1 py-5 bg-blue-600 text-white rounded-[2rem] font-black text-[10px] uppercase tracking-widest shadow-2xl shadow-blue-600/30 hover:bg-blue-700 transition-all">Simpan Data</button>
               </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default HouseholdModule;
