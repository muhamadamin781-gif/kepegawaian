
import React, { useState, useRef } from 'react';
import { Camera, MapPin, UserCheck, AlertTriangle, ShieldCheck, Zap } from 'lucide-react';
import { User, UserRole } from '../types';

const PpnpnPresence: React.FC<{ user: User }> = ({ user }) => {
  const [step, setStep] = useState<'IDLE' | 'CAMERA' | 'DONE'>('IDLE');
  const [photo, setPhoto] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    setStep('CAMERA');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      alert("Gagal mengakses kamera. Izin diperlukan.");
      setStep('IDLE');
    }
  };

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        context.drawImage(videoRef.current, 0, 0, 400, 300);
        const dataUrl = canvasRef.current.toDataURL('image/png');
        setPhoto(dataUrl);
        setStep('DONE');
        // Stop camera stream
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6">
            <div className="bg-emerald-50 text-emerald-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100 flex items-center gap-2">
               <Zap className="w-3 h-3 fill-emerald-600" /> System Live
            </div>
        </div>
        
        <div className="flex flex-col md:flex-row gap-10">
          <div className="flex-1 space-y-6">
            <div>
              <h2 className="text-3xl font-black text-slate-900 tracking-tighter italic">Check-In Kehadiran</h2>
              <p className="text-slate-500 font-medium mt-1">Sistem Anti-Titip Absen Berbasis AI & Geofencing</p>
            </div>

            <div className="space-y-4">
               <div className="p-5 bg-blue-50 rounded-2xl border border-blue-100 flex items-center gap-4">
                  <div className="bg-blue-600 p-3 rounded-xl">
                    <MapPin className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Radius Geofencing</p>
                    <p className="text-sm font-black text-blue-900">Dalam Jangkauan (Kantor Serang)</p>
                  </div>
               </div>
               
               <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 flex items-center gap-4">
                  <div className="bg-slate-400 p-3 rounded-xl">
                    <ShieldCheck className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Perangkat Terdaftar</p>
                    <p className="text-sm font-black text-slate-700">Mobile Unit #082 - Terverifikasi</p>
                  </div>
               </div>
            </div>

            {step === 'IDLE' && (
              <button 
                onClick={startCamera}
                className="w-full py-5 bg-blue-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-3"
              >
                <Camera className="w-5 h-5" /> Ambil Foto Selfie
              </button>
            )}
          </div>

          <div className="w-full md:w-[400px]">
            <div className="aspect-[4/3] bg-slate-900 rounded-[2rem] overflow-hidden relative shadow-2xl">
              {step === 'IDLE' && (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 space-y-4">
                  <Camera className="w-12 h-12 opacity-20" />
                  <span className="text-xs font-bold uppercase tracking-widest opacity-40">Preview Kamera</span>
                </div>
              )}
              {step === 'CAMERA' && (
                <>
                  <video ref={videoRef} className="w-full h-full object-cover scale-x-[-1]" />
                  <div className="absolute inset-0 border-[40px] border-slate-900/40 pointer-events-none">
                     <div className="w-full h-full border-2 border-white/50 rounded-full border-dashed"></div>
                  </div>
                  <button 
                    onClick={takePhoto}
                    className="absolute bottom-6 left-1/2 -translate-x-1/2 p-5 bg-white rounded-full shadow-2xl hover:scale-110 active:scale-95 transition-all"
                  >
                    <div className="w-6 h-6 rounded-full bg-blue-600"></div>
                  </button>
                </>
              )}
              {step === 'DONE' && photo && (
                <>
                  <img src={photo} className="w-full h-full object-cover scale-x-[-1]" />
                  <div className="absolute inset-0 bg-emerald-500/10 flex items-center justify-center">
                    <div className="bg-white/90 backdrop-blur px-6 py-3 rounded-2xl shadow-2xl border border-white">
                       <span className="text-emerald-700 font-black text-xs uppercase tracking-widest flex items-center gap-2">
                         <UserCheck className="w-4 h-4" /> Foto Terverifikasi
                       </span>
                    </div>
                  </div>
                </>
              )}
            </div>
            {step === 'DONE' && (
              <button 
                onClick={() => alert("Absensi Berhasil Disimpan!")}
                className="mt-6 w-full py-5 bg-emerald-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-emerald-500/20 hover:bg-emerald-700 transition-all flex items-center justify-center gap-3"
              >
                Kirim Laporan Kehadiran
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-100 p-6 rounded-3xl flex items-start gap-4">
         <AlertTriangle className="w-6 h-6 text-amber-500 shrink-0" />
         <div>
            <h4 className="font-black text-amber-900 text-sm uppercase tracking-tighter">Ketentuan Kehadiran</h4>
            <p className="text-xs text-amber-700 font-medium leading-relaxed mt-1">
              Berdasarkan aturan KPKNL Serang, keterlambatan dihitung per menit & detik. 
              Gunakan perangkat yang terdaftar untuk menghindari blokir akun otomatis oleh AI Security.
            </p>
         </div>
      </div>
    </div>
  );
};

export default PpnpnPresence;
