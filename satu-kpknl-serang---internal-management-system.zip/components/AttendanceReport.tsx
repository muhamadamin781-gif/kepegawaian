
import React, { useState } from 'react';
import { Download, Filter, Search, Calendar, FileText, Table as TableIcon, Clock, AlertTriangle } from 'lucide-react';
import { UserRole, AttendanceRecord } from '../types';

interface AttendanceReportProps {
  isPersonalView?: boolean;
  currentUserId?: string;
}

const MOCK_RECORDS: AttendanceRecord[] = [
  { id: '1', userId: 'P1', userName: 'Supardi', role: UserRole.SATPAM, date: '2024-09-10', checkIn: '07:45', checkOut: '19:45', lateMinutes: 15, status: 'Terlambat' },
  { id: '2', userId: 'P2', userName: 'Ahmad Faisal', role: UserRole.DRIVER, date: '2024-09-10', checkIn: '07:25', checkOut: '17:15', lateMinutes: 0, status: 'Hadir' },
  { id: '3', userId: 'P3', userName: 'Siska', role: UserRole.PRAMUBAKTI, date: '2024-09-10', checkIn: '07:55', checkOut: '17:00', lateMinutes: 25, status: 'Terlambat' },
  { id: '4', userId: 'P4', userName: 'Budi', role: UserRole.CS, date: '2024-09-10', checkIn: '06:00', checkOut: '16:00', lateMinutes: 0, status: 'Hadir' },
];

const AttendanceReport: React.FC<AttendanceReportProps> = ({ isPersonalView, currentUserId }) => {
  const [records] = useState(MOCK_RECORDS);
  const [filterDate, setFilterDate] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredRecords = records.filter(r => {
    const matchesUser = isPersonalView ? (r.userName.toLowerCase().includes('supardi') || r.userName.toLowerCase().includes('siska')) : true; // Mock logic for personal view
    const matchesSearch = r.userName.toLowerCase().includes(searchTerm.toLowerCase()) || r.role.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDate = filterDate ? r.date === filterDate : true;
    return matchesUser && matchesSearch && matchesDate;
  });

  const handleDownload = (format: 'excel' | 'pdf') => {
    alert(`Mengekspor Laporan Presensi dalam format ${format.toUpperCase()}...`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tighter italic">
            {isPersonalView ? 'Riwayat Kehadiran Saya' : 'Laporan Presensi PPNPN'}
          </h2>
          <p className="text-slate-500 text-sm font-medium">
            {isPersonalView ? 'Pantau kedisiplinan dan akumulasi jam kerja Anda' : 'Monitoring kehadiran dan akumulasi keterlambatan seluruh staf'}
          </p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => handleDownload('excel')} className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-emerald-500/20 hover:bg-emerald-700 transition-all">
            <TableIcon className="w-4 h-4" /> Download Excel
          </button>
          <button onClick={() => handleDownload('pdf')} className="flex items-center gap-2 px-6 py-3 bg-rose-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-rose-500/20 hover:bg-rose-700 transition-all">
            <FileText className="w-4 h-4" /> Download PDF
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-xl"><Clock className="w-5 h-5" /></div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Rata-rata Keterlambatan</p>
          </div>
          <p className="text-3xl font-black text-slate-900 italic">12.5 <span className="text-sm font-bold text-slate-400">Menit / Hari</span></p>
        </div>
        <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl"><Calendar className="w-5 h-5" /></div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tingkat Kehadiran</p>
          </div>
          <p className="text-3xl font-black text-slate-900 italic">94.8 <span className="text-sm font-bold text-slate-400">%</span></p>
        </div>
        <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-rose-50 text-rose-600 rounded-xl"><AlertTriangle className="w-5 h-5" /></div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Sanksi Keterlambatan</p>
          </div>
          <p className="text-3xl font-black text-rose-600 italic">Rp 450.000</p>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6">
           <div className="relative w-full md:w-80">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Cari Nama / Role..." 
                className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-blue-500 text-xs font-bold"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
           </div>
           <div className="flex gap-4">
              <input 
                type="date" 
                className="px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-black uppercase tracking-widest text-slate-600 outline-none" 
                value={filterDate}
                onChange={e => setFilterDate(e.target.value)}
              />
              <button className="flex items-center gap-2 px-6 py-3 bg-slate-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-black transition-all">
                <Filter className="w-4 h-4" /> Filter
              </button>
           </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
                <th className="px-10 py-6">Pegawai</th>
                <th className="px-10 py-6">Tanggal</th>
                <th className="px-10 py-6">Masuk</th>
                <th className="px-10 py-6">Pulang</th>
                <th className="px-10 py-6">Telat (Menit)</th>
                <th className="px-10 py-6">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length > 0 ? filteredRecords.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50/50 transition-all">
                  <td className="px-10 py-6">
                    <p className="text-sm font-black text-slate-900">{r.userName}</p>
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{r.role.replace('_', ' ')}</p>
                  </td>
                  <td className="px-10 py-6 text-xs font-bold text-slate-600">{r.date}</td>
                  <td className="px-10 py-6 text-xs font-black text-slate-900">{r.checkIn}</td>
                  <td className="px-10 py-6 text-xs font-black text-slate-900">{r.checkOut}</td>
                  <td className="px-10 py-6">
                    <span className={`text-xs font-black ${r.lateMinutes > 0 ? 'text-rose-600 bg-rose-50 px-3 py-1 rounded-lg' : 'text-slate-400'}`}>
                      {r.lateMinutes} Menit
                    </span>
                  </td>
                  <td className="px-10 py-6">
                    <span className={`text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full border ${
                      r.status === 'Hadir' ? 'border-emerald-100 bg-emerald-50 text-emerald-600' : 'border-rose-100 bg-rose-50 text-rose-600'
                    }`}>
                      {r.status}
                    </span>
                  </td>
                </tr>
              )) : (
                <tr>
                   <td colSpan={6} className="px-10 py-20 text-center text-slate-400 font-bold uppercase tracking-widest text-xs">
                      Tidak ada rekaman data ditemukan
                   </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AttendanceReport;
