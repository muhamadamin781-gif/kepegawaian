
import React, { useMemo } from 'react';
import { 
  Users, 
  Truck, 
  Clock, 
  AlertTriangle,
  ArrowUpRight,
  ArrowDownLeft,
  Activity
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area 
} from 'recharts';

const MOCK_CHART_DATA = [
  { time: '08:00', presence: 12, vehicle: 5 },
  { time: '10:00', presence: 45, vehicle: 12 },
  { time: '12:00', presence: 50, vehicle: 8 },
  { time: '14:00', presence: 48, vehicle: 15 },
  { time: '16:00', presence: 30, vehicle: 22 },
  { time: '18:00', presence: 10, vehicle: 18 },
];

const StatCard: React.FC<{ 
  title: string; 
  value: string | number; 
  change: string; 
  isPositive: boolean; 
  icon: React.ElementType;
  color: string;
}> = ({ title, value, change, isPositive, icon: Icon, color }) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm transition-transform hover:scale-[1.02]">
    <div className="flex justify-between items-start mb-4">
      <div className={`p-3 rounded-xl ${color}`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div className={`flex items-center gap-1 text-xs font-bold ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
        {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownLeft className="w-3 h-3" />}
        {change}
      </div>
    </div>
    <p className="text-slate-500 text-sm font-medium">{title}</p>
    <h3 className="text-2xl font-bold text-slate-900 mt-1">{value}</h3>
  </div>
);

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Kehadiran Hari Ini" 
          value="156" 
          change="+12.5%" 
          isPositive={true} 
          icon={Users} 
          color="bg-blue-600" 
        />
        <StatCard 
          title="Kendaraan Masuk" 
          value="42" 
          change="+3.2%" 
          isPositive={true} 
          icon={Truck} 
          color="bg-indigo-600" 
        />
        <StatCard 
          title="Rata-rata Durasi" 
          value="6h 45m" 
          change="-0.5%" 
          isPositive={false} 
          icon={Clock} 
          color="bg-amber-500" 
        />
        <StatCard 
          title="Alert Keamanan" 
          value="0" 
          change="Sesuai" 
          isPositive={true} 
          icon={AlertTriangle} 
          color="bg-emerald-500" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-lg font-bold text-slate-800">Trafik Gatehouse</h3>
              <p className="text-sm text-slate-500">Aktivitas real-time gerbang utama</p>
            </div>
            <div className="flex gap-2">
              <span className="flex items-center gap-1.5 text-xs text-blue-600 font-semibold bg-blue-50 px-3 py-1 rounded-full">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-600"></div>
                Absensi
              </span>
              <span className="flex items-center gap-1.5 text-xs text-indigo-600 font-semibold bg-indigo-50 px-3 py-1 rounded-full">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-600"></div>
                Kendaraan
              </span>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_CHART_DATA}>
                <defs>
                  <linearGradient id="colorPresence" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="time" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="presence" stroke="#2563eb" fillOpacity={1} fill="url(#colorPresence)" strokeWidth={3} />
                <Area type="monotone" dataKey="vehicle" stroke="#4f46e5" fillOpacity={0} strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          <div className="flex items-center gap-2 mb-6">
            <Activity className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-bold text-slate-800">Aktivitas Terkini</h3>
          </div>
          <div className="space-y-5 flex-1 overflow-y-auto">
            {[
              { type: 'VEHICLE', action: 'Kendaraan Masuk', detail: 'B 1234 XYZ (Logistik)', time: '2m ago' },
              { type: 'PRESENCE', action: 'Check-in Staf', detail: 'Budi Santoso - HRD', time: '5m ago' },
              { type: 'VEHICLE', action: 'Kendaraan Keluar', detail: 'F 9988 AB (Operasional)', time: '12m ago' },
              { type: 'PRESENCE', action: 'Check-in Staf', detail: 'Siska Amelia - IT', time: '15m ago' },
              { type: 'PRESENCE', action: 'Check-in Staf', detail: 'Ahmad Faisal - Security', time: '18m ago' },
            ].map((activity, idx) => (
              <div key={idx} className="flex gap-4 border-l-2 border-slate-100 pl-4 relative group">
                <div className="absolute -left-[5px] top-1 w-2 h-2 rounded-full bg-slate-300 group-hover:bg-blue-500 transition-colors"></div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <p className="text-sm font-bold text-slate-800">{activity.action}</p>
                    <span className="text-[10px] text-slate-400 font-medium">{activity.time}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{activity.detail}</p>
                </div>
              </div>
            ))}
          </div>
          <button className="mt-6 w-full py-2.5 text-sm font-semibold text-blue-600 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors">
            Lihat Semua Aktivitas
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
