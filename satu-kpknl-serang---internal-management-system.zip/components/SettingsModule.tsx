
import React, { useState, useRef } from 'react';
import { 
  User as UserIcon, 
  Lock, 
  Shield, 
  Camera, 
  CheckCircle, 
  Users, 
  UserCog, 
  Save,
  ShieldCheck,
  Eye,
  EyeOff
} from 'lucide-react';
import { User, UserRole } from '../types';

interface SettingsModuleProps {
  currentUser: User;
  users: User[];
  onUpdateUsers: (updatedUsers: User[]) => void;
  onUpdateSelf: (updatedUser: User) => void;
}

const SettingsModule: React.FC<SettingsModuleProps> = ({ currentUser, users, onUpdateUsers, onUpdateSelf }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'access'>('profile');
  const [profileData, setProfileData] = useState<Partial<User>>({
    name: currentUser.name,
    password: currentUser.password,
    photo: currentUser.photo
  });
  const [showPassword, setShowPassword] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedUser = { ...currentUser, ...profileData } as User;
    onUpdateSelf(updatedUser);
    alert("Profil Admin berhasil diperbarui!");
  };

  const handleRoleChange = (userId: string, newRole: UserRole) => {
    const updatedUsers = users.map(u => u.id === userId ? { ...u, role: newRole } : u);
    onUpdateUsers(updatedUsers);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileData(prev => ({ ...prev, photo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tighter italic">Pengaturan Sistem</h2>
          <p className="text-slate-500 font-medium mt-1">Konfigurasi profil personal dan hak akses pegawai</p>
        </div>
      </div>

      <div className="flex gap-4 p-2 bg-white border border-slate-200 rounded-[2rem] w-fit shadow-sm">
        <button 
          onClick={() => setActiveTab('profile')}
          className={`px-8 py-3 rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'profile' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <UserIcon className="w-4 h-4" /> Profil Saya
        </button>
        <button 
          onClick={() => setActiveTab('access')}
          className={`px-8 py-3 rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === 'access' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <Shield className="w-4 h-4" /> Manajemen Akses
        </button>
      </div>

      {activeTab === 'profile' && (
        <div className="bg-white rounded-[3rem] border border-slate-200 shadow-sm overflow-hidden animate-in slide-in-from-bottom-4">
          <div className="p-8 bg-slate-900 text-white flex items-center gap-4">
            <div className="bg-blue-600 p-2.5 rounded-xl">
              <UserCog className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-black italic tracking-tighter">Edit Profil Admin</h3>
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Data login & identitas pribadi</p>
            </div>
          </div>

          <form onSubmit={handleProfileUpdate} className="p-12 space-y-10">
            <div className="flex flex-col md:flex-row gap-12 items-center md:items-start">
              <div className="relative group">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-48 h-48 rounded-[3rem] bg-slate-100 border-4 border-white shadow-xl flex items-center justify-center overflow-hidden cursor-pointer active:scale-95 transition-all"
                >
                  {profileData.photo ? (
                    <img src={profileData.photo} className="w-full h-full object-cover" />
                  ) : (
                    <div className="text-center">
                      <Camera className="w-10 h-10 text-slate-300 mx-auto" />
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-2">Pilih Foto</p>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                    <Camera className="w-8 h-8 text-white" />
                    <span className="text-white text-[10px] font-black uppercase tracking-widest">Ganti Foto</span>
                  </div>
                </div>
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload} />
              </div>

              <div className="flex-1 space-y-6 w-full">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nama Lengkap Admin</label>
                  <div className="relative">
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                    <input 
                      required 
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold transition-all" 
                      value={profileData.name} 
                      onChange={e => setProfileData({...profileData, name: e.target.value})} 
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Ganti Kata Sandi</label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                    <input 
                      type={showPassword ? "text" : "password"} 
                      required 
                      className="w-full pl-12 pr-12 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold transition-all" 
                      value={profileData.password} 
                      onChange={e => setProfileData({...profileData, password: e.target.value})} 
                    />
                    <button 
                      type="button" 
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-blue-600 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="pt-6">
                  <button type="submit" className="w-full md:w-auto px-12 py-5 bg-blue-600 text-white rounded-[2rem] font-black text-[10px] uppercase tracking-widest shadow-2xl shadow-blue-600/30 hover:bg-blue-700 transition-all flex items-center justify-center gap-3 active:scale-95">
                    <Save className="w-4 h-4" /> Simpan Perubahan Profil
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      )}

      {activeTab === 'access' && (
        <div className="bg-white rounded-[3rem] border border-slate-200 shadow-sm overflow-hidden animate-in slide-in-from-bottom-4">
          <div className="p-8 bg-slate-900 text-white flex items-center gap-4">
            <div className="bg-emerald-600 p-2.5 rounded-xl">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-black italic tracking-tighter">Manajemen Rolle Pegawai</h3>
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Tetapkan otoritas pengguna sistem</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 border-b border-slate-100">
                  <th className="px-10 py-6">Pegawai</th>
                  <th className="px-10 py-6">Status Akun</th>
                  <th className="px-10 py-6">Pilih Rolle</th>
                  <th className="px-10 py-6 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/50 transition-all group">
                    <td className="px-10 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-black text-xs overflow-hidden border border-slate-100 shadow-sm">
                          {u.photo ? <img src={u.photo} className="w-full h-full object-cover" /> : u.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-black text-slate-900 italic">{u.name}</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">@{u.username}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-10 py-6">
                      <span className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-lg text-[9px] font-black uppercase tracking-widest border border-emerald-100">
                        <CheckCircle className="w-3 h-3" /> Aktif
                      </span>
                    </td>
                    <td className="px-10 py-6">
                      <select 
                        className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-black uppercase tracking-widest outline-none focus:border-blue-500 transition-all"
                        value={u.role}
                        onChange={(e) => handleRoleChange(u.id, e.target.value as UserRole)}
                      >
                        <option value={UserRole.ADMIN}>ADMIN</option>
                        <option value={UserRole.KSBU}>KSBU</option>
                        <option value={UserRole.PNS}>PNS</option>
                        <option value={UserRole.SATPAM}>SATPAM</option>
                        <option value={UserRole.DRIVER}>DRIVER</option>
                        <option value={UserRole.PRAMUBAKTI}>PRAMUBAKTI</option>
                        <option value={UserRole.CS}>CLEANING SERVICE</option>
                      </select>
                    </td>
                    <td className="px-10 py-6 text-right">
                      <button className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline">
                        Log Aktivitas
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-8 bg-slate-50 border-t border-slate-100 text-center">
            <p className="text-[10px] font-bold text-slate-400 italic">Perubahan rolle akan langsung berdampak pada menu navigasi yang tersedia untuk pengguna tersebut.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsModule;
