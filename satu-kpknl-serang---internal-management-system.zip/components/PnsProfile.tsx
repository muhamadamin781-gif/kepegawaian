
import React, { useState, useRef } from 'react';
import { User } from '../types';
import { 
  Award, 
  TrendingUp, 
  FileText, 
  Download, 
  Edit3, 
  Camera, 
  Check, 
  X, 
  User as UserIcon, 
  MapPin, 
  Phone, 
  GraduationCap, 
  Briefcase,
  Lock,
  Eye,
  EyeOff,
  AtSign,
  ShieldCheck,
  Fingerprint
} from 'lucide-react';

interface EmployeeProfileProps {
  user: User;
  onUpdateProfile: (updatedUser: User) => void;
}

const EmployeeProfile: React.FC<EmployeeProfileProps> = ({ user, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState<User>({ ...user });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = () => {
    if (!formData.username || formData.username.length < 3) {
      alert("Username minimal 3 karakter!");
      return;
    }
    if (formData.password && formData.password.length < 3) {
      alert("Password minimal 3 karakter!");
      return;
    }
    onUpdateProfile(formData);
    setIsEditing(false);
    alert("Profil dan Akun Keamanan anda berhasil diperbarui!");
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const updatedUser = { ...formData, photo: reader.result as string };
        setFormData(updatedUser);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700 max-w-6xl mx-auto">
      {/* Profile Header Card */}
      <div className="bg-white rounded-[3rem] p-10 border border-slate-200 shadow-sm flex flex-col md:flex-row gap-12 items-center md:items-start relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-50/50 rounded-full translate-x-32 -translate-y-32"></div>
        
        {/* Avatar Section */}
        <div className="relative group shrink-0">
           <div 
             onClick={() => isEditing && fileInputRef.current?.click()}
             className={`w-44 h-44 rounded-[3rem] bg-slate-900 border-4 border-white shadow-2xl flex items-center justify-center text-5xl font-black text-white transform transition-all overflow-hidden ${isEditing ? 'cursor-pointer hover:rotate-2 scale-105' : ''}`}
           >
             {formData.photo ? (
               <img src={formData.photo} className="w-full h-full object-cover" />
             ) : (
               <div className="flex flex-col items-center">
                  <span className="text-4xl">{formData.name.charAt(0)}</span>
               </div>
             )}
             {isEditing && (
               <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center">
                  <Camera className="w-8 h-8 text-white mb-2" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-white">Ganti Foto</span>
               </div>
             )}
           </div>
           <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload} />
           <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shadow-xl border-4 border-white">
              <ShieldCheck className="w-5 h-5 text-white" />
           </div>
        </div>

        {/* Info & Edit Toggle */}
        <div className="flex-1 space-y-8 text-center md:text-left relative z-10 w-full">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div className="flex-1 w-full">
              {isEditing ? (
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nama Lengkap Pegawai</label>
                  <input 
                    className="text-3xl font-black text-slate-900 tracking-tighter bg-slate-50 border-2 border-slate-100 rounded-2xl px-6 py-3 outline-none w-full italic focus:border-blue-500 transition-all"
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
              ) : (
                <>
                  <h2 className="text-4xl font-black text-slate-900 tracking-tighter italic">{formData.name}</h2>
                  <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 mt-3">
                    <div className="flex items-center gap-2 text-slate-400">
                      <Briefcase className="w-4 h-4" />
                      <p className="font-bold uppercase tracking-widest text-[10px]">{formData.section || 'Staf Internal'}</p>
                    </div>
                    <div className="flex items-center gap-2 text-blue-500 bg-blue-50 px-3 py-1 rounded-full">
                      <Fingerprint className="w-3 h-3" />
                      <p className="font-black text-[10px] uppercase tracking-widest">@{formData.username}</p>
                    </div>
                  </div>
                </>
              )}
            </div>
            <div className="flex gap-3 justify-center shrink-0">
              {isEditing ? (
                <>
                  <button onClick={() => setIsEditing(false)} className="flex items-center gap-2 px-6 py-3 bg-slate-100 text-slate-500 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all">
                    <X className="w-4 h-4" /> Batal
                  </button>
                  <button onClick={handleSave} className="flex items-center gap-2 px-8 py-3 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all">
                    <Check className="w-4 h-4" /> Simpan Perubahan
                  </button>
                </>
              ) : (
                <button onClick={() => setIsEditing(true)} className="flex items-center gap-2 px-8 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-slate-900/10">
                  <Edit3 className="w-4 h-4" /> Edit Profil & Akun
                </button>
              )}
            </div>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
            <div className="p-5 bg-slate-50 rounded-3xl border border-slate-100 group hover:border-blue-200 transition-colors">
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Jabatan / Role</p>
               <p className="text-sm font-black text-slate-800 mt-1 italic">{user.role.replace('_', ' ')}</p>
            </div>
            <div className="p-5 bg-slate-50 rounded-3xl border border-slate-100 group hover:border-blue-200 transition-colors">
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">ID Pegawai (NIP)</p>
               <p className="text-sm font-black text-slate-800 mt-1">{formData.nip || '-'}</p>
            </div>
            <div className="p-5 bg-slate-50 rounded-3xl border border-slate-100 group hover:border-blue-200 transition-colors">
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Jam Kerja</p>
               <p className="text-sm font-black text-blue-600 mt-1">{formData.workHours || '07:30 - 17:00'}</p>
            </div>
            <div className="p-5 bg-slate-50 rounded-3xl border border-slate-100 group hover:border-blue-200 transition-colors">
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Status Akun</p>
               <p className="text-sm font-black text-emerald-600 mt-1 uppercase">Aktif</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
         <div className="lg:col-span-1 space-y-8">
            {/* Account Security Section */}
            <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden p-8">
               <h3 className="font-black text-slate-900 uppercase tracking-widest text-xs mb-8 flex items-center gap-2">
                 <Lock className="w-4 h-4 text-rose-500" /> Keamanan Akun
               </h3>
               <div className="space-y-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                        <AtSign className="w-3 h-3" /> Username
                      </label>
                      <div className="relative">
                        <input 
                          disabled={!isEditing}
                          className={`w-full px-5 py-3 rounded-2xl text-sm font-bold outline-none transition-all ${
                            isEditing ? 'bg-slate-50 border-2 border-slate-200 focus:border-blue-500' : 'bg-slate-100 border-2 border-transparent text-slate-500 cursor-not-allowed'
                          }`}
                          value={formData.username}
                          onChange={e => setFormData({...formData, username: e.target.value})}
                          placeholder="Username login..."
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                        <Lock className="w-3 h-3" /> Kata Sandi
                      </label>
                      <div className="relative">
                        <input 
                          type={showPassword ? "text" : "password"}
                          disabled={!isEditing}
                          className={`w-full px-5 py-3 rounded-2xl text-sm font-bold outline-none transition-all pr-12 ${
                            isEditing ? 'bg-slate-50 border-2 border-slate-200 focus:border-rose-500' : 'bg-slate-100 border-2 border-transparent text-slate-500 cursor-not-allowed'
                          }`}
                          value={formData.password}
                          onChange={e => setFormData({...formData, password: e.target.value})}
                          placeholder="Isi untuk ubah password..."
                        />
                        <button 
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-blue-600 transition-colors"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </div>
                  {!isEditing && (
                    <p className="text-[10px] text-slate-400 italic font-medium leading-relaxed">
                      Klik tombol edit di atas untuk mengaktifkan perubahan username dan password akun anda.
                    </p>
                  )}
               </div>
            </div>

            <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden p-8">
               <h3 className="font-black text-slate-900 uppercase tracking-widest text-xs mb-8 flex items-center gap-2">
                 <UserIcon className="w-4 h-4 text-blue-600" /> Kontak & Domisili
               </h3>
               <div className="space-y-6">
                  <div className="flex items-start gap-4">
                     <div className="p-2.5 bg-slate-50 rounded-xl"><Phone className="w-4 h-4 text-slate-400" /></div>
                     <div className="flex-1">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">No. Handphone</p>
                        {isEditing ? (
                          <input className="text-sm font-bold text-slate-900 mt-1 bg-slate-50 border-b border-slate-200 w-full outline-none focus:border-blue-500 py-1" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                        ) : (
                          <p className="text-sm font-bold text-slate-900 mt-1">{formData.phone || '-'}</p>
                        )}
                     </div>
                  </div>
                  <div className="flex items-start gap-4">
                     <div className="p-2.5 bg-slate-50 rounded-xl"><MapPin className="w-4 h-4 text-slate-400" /></div>
                     <div className="flex-1">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Alamat Lengkap</p>
                        {isEditing ? (
                          <textarea className="text-sm font-bold text-slate-900 mt-1 bg-slate-50 border-b border-slate-200 w-full outline-none min-h-[80px] focus:border-blue-500 py-1" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} />
                        ) : (
                          <p className="text-sm font-bold text-slate-900 mt-1 leading-relaxed italic">{formData.address || '-'}</p>
                        )}
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <div className="lg:col-span-2 space-y-8">
            <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
               <div className="p-8 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="font-black text-slate-900 uppercase tracking-widest text-xs flex items-center gap-2">
                    <Award className="w-5 h-5 text-blue-600" /> Riwayat Pengembangan Kompetensi
                  </h3>
               </div>
               <div className="p-8 space-y-6">
                 {[
                   { name: 'Diklat Teknis Penilaian Aset', type: 'Fungsional', date: 'Mei 2024', hours: '20 JP' },
                   { name: 'Pelatihan Service Excellence', type: 'Teknis', date: 'Mar 2024', hours: '12 JP' },
                 ].map((d, i) => (
                   <div key={i} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-6 bg-slate-50 rounded-[2.5rem] group hover:bg-white hover:shadow-xl hover:border-slate-100 transition-all border-2 border-transparent gap-6">
                      <div className="flex gap-5">
                         <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center border border-slate-200 shadow-sm">
                            <FileText className="w-6 h-6 text-slate-400" />
                         </div>
                         <div>
                           <p className="text-base font-black text-slate-900 italic tracking-tight">{d.name}</p>
                           <p className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.1em] mt-1">{d.type} • {d.date}</p>
                         </div>
                      </div>
                      <div className="flex items-center gap-6 w-full sm:w-auto">
                         <div className="text-right flex-1 sm:flex-none">
                            <p className="text-sm font-black text-slate-800">{d.hours}</p>
                            <p className="text-[9px] font-bold text-emerald-600 uppercase tracking-widest">Sertifikat Terbit</p>
                         </div>
                         <button className="flex items-center gap-2 px-5 py-2.5 bg-white border-2 border-slate-100 rounded-xl text-[10px] font-black text-blue-600 uppercase tracking-widest hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all shadow-sm">
                           <Download className="w-4 h-4" /> Unduh
                         </button>
                      </div>
                   </div>
                 ))}
               </div>
            </div>

            <div className="bg-slate-900 rounded-[2.5rem] p-10 text-white relative overflow-hidden shadow-2xl">
               <div className="absolute top-0 right-0 p-10 opacity-10">
                  <TrendingUp className="w-40 h-40" />
               </div>
               <h3 className="text-2xl font-black italic tracking-tighter relative z-10">Insight Performa Kerja</h3>
               <p className="text-slate-400 text-sm font-medium mt-4 leading-relaxed max-w-xl relative z-10">
                 Berdasarkan data presensi dan capaian IKU triwulan ini, performa kerja Anda berada di atas rata-rata nasional. 
                 Teruskan dedikasi untuk KPKNL Serang yang lebih baik.
               </p>
               <div className="mt-8 flex gap-4 relative z-10">
                  <div className="bg-white/10 px-6 py-4 rounded-3xl backdrop-blur border border-white/5">
                     <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Capaian IKU</p>
                     <p className="text-2xl font-black italic mt-1">104.5%</p>
                  </div>
                  <div className="bg-white/10 px-6 py-4 rounded-3xl backdrop-blur border border-white/5">
                     <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Absensi</p>
                     <p className="text-2xl font-black italic mt-1">98.2%</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default EmployeeProfile;
