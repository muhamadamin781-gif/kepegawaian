
import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  FileText, 
  Upload, 
  X, 
  CheckCircle, 
  Clock, 
  RefreshCcw,
  Briefcase,
  User,
  Package
} from 'lucide-react';
import { User as UserType, ProposalStatus, ProcurementProposal } from '../types';

interface ProcurementModuleProps {
  currentUser: UserType;
  proposals: ProcurementProposal[];
  onAddProposal: (proposal: ProcurementProposal) => void;
  isAdminView?: boolean;
}

const ProcurementModule: React.FC<ProcurementModuleProps> = ({ currentUser, proposals, onAddProposal, isAdminView }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<ProcurementProposal>>({
    itemProposed: '',
    section: currentUser.section || '',
    attachment: ''
  });

  const handleOpenAdd = () => {
    setFormData({ itemProposed: '', section: currentUser.section || '', attachment: '' });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newProposal: ProcurementProposal = {
      id: Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      userName: currentUser.name,
      section: formData.section || '',
      itemProposed: formData.itemProposed || '',
      status: ProposalStatus.PROPOSED,
      date: new Date().toLocaleDateString('id-ID'),
      attachment: formData.attachment
    };
    onAddProposal(newProposal);
    setIsModalOpen(false);
    alert("Usulan pengadaan berhasil diajukan!");
  };

  const getStatusStyle = (status: ProposalStatus) => {
    switch (status) {
      case ProposalStatus.PROPOSED: return 'bg-blue-50 text-blue-600 border-blue-100';
      case ProposalStatus.PROCESSING: return 'bg-amber-50 text-amber-600 border-amber-100';
      case ProposalStatus.COMPLETED: return 'bg-emerald-50 text-emerald-600 border-emerald-100';
      default: return 'bg-slate-50 text-slate-600 border-slate-100';
    }
  };

  const filteredProposals = isAdminView ? proposals : proposals.filter(p => p.userId === currentUser.id);

  return (
    <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tighter italic">Usulan Pengadaan</h2>
          <p className="text-slate-500 text-sm font-medium">Monitoring permohonan pengadaan barang dan jasa</p>
        </div>
        {!isAdminView && (
          <button 
            onClick={handleOpenAdd}
            className="flex items-center gap-3 px-8 py-4 bg-blue-600 text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all hover:bg-blue-700"
          >
            <Plus className="w-5 h-5" /> Tambah Usulan
          </button>
        )}
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100 bg-slate-50/30 flex flex-col md:flex-row gap-4 justify-between items-center">
           <div className="relative w-full md:w-96">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input type="text" placeholder="Cari Usulan..." className="w-full pl-14 pr-6 py-4 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all text-xs font-bold" />
           </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-[10px] uppercase tracking-[0.2em] text-slate-400 font-black">
                <th className="px-10 py-6">Nama / Seksi</th>
                <th className="px-10 py-6">Barang Diusulkan</th>
                <th className="px-10 py-6">Tanggal</th>
                <th className="px-10 py-6">Status</th>
                <th className="px-10 py-6 text-right">Lampiran</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProposals.length > 0 ? filteredProposals.map((p) => (
                <tr key={p.id} className="group hover:bg-slate-50/50 transition-all">
                  <td className="px-10 py-6">
                    <p className="text-sm font-black text-slate-900 italic">{p.userName}</p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{p.section}</p>
                  </td>
                  <td className="px-10 py-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-50 rounded-lg"><Package className="w-4 h-4 text-blue-600" /></div>
                      <p className="text-sm font-black text-slate-800 italic">{p.itemProposed}</p>
                    </div>
                  </td>
                  <td className="px-10 py-6 text-xs font-bold text-slate-500">
                    {p.date}
                  </td>
                  <td className="px-10 py-6">
                    <span className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border ${getStatusStyle(p.status)}`}>
                      {p.status === ProposalStatus.PROPOSED && <Clock className="w-3 h-3" />}
                      {p.status === ProposalStatus.PROCESSING && <RefreshCcw className="w-3 h-3 animate-spin" />}
                      {p.status === ProposalStatus.COMPLETED && <CheckCircle className="w-3 h-3" />}
                      {p.status}
                    </span>
                  </td>
                  <td className="px-10 py-6 text-right">
                    <button className="p-3 text-slate-300 hover:text-blue-600 hover:bg-white rounded-xl transition-all border border-transparent hover:border-slate-100">
                      <FileText className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="px-10 py-20 text-center">
                    <div className="flex flex-col items-center opacity-20">
                      <FileText className="w-16 h-16 mb-4" />
                      <p className="font-black uppercase tracking-widest text-xs">Belum ada usulan diajukan</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-8 bg-slate-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-black italic tracking-tighter">Tambah Usulan Baru</h3>
                <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-1">Satu KPKNL Serang Procurement System</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-all"><X className="w-6 h-6" /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-10 space-y-6 bg-white">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nama Pemohon</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                  <input readOnly className="w-full pl-12 pr-4 py-4 bg-slate-100 border-2 border-slate-100 rounded-2xl text-sm font-bold text-slate-500 cursor-not-allowed" value={currentUser.name} />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Seksi / Unit Kerja</label>
                <div className="relative">
                  <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                  <input required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.section} onChange={e => setFormData({...formData, section: e.target.value})} placeholder="Seksi HI / Umum / dsb..." />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Barang / Jasa yang Diusulkan</label>
                <div className="relative">
                  <Package className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                  <input required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.itemProposed} onChange={e => setFormData({...formData, itemProposed: e.target.value})} placeholder="Contoh: Penggantian AC Ruang Rapat..." />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Unggah Lampiran (PDF/Gambar)</label>
                <div className="border-2 border-dashed border-slate-200 rounded-2xl p-8 flex flex-col items-center justify-center text-slate-400 hover:border-blue-400 hover:text-blue-500 transition-all cursor-pointer">
                  <Upload className="w-8 h-8 mb-2" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Pilih Berkas Lampiran</span>
                </div>
              </div>

              <div className="pt-6 border-t border-slate-100 flex gap-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-5 bg-slate-100 text-slate-400 rounded-[2rem] font-black text-[10px] uppercase tracking-widest hover:bg-slate-200 transition-all">Batalkan</button>
                <button type="submit" className="flex-1 py-5 bg-blue-600 text-white rounded-[2rem] font-black text-[10px] uppercase tracking-widest shadow-2xl shadow-blue-500/30 hover:bg-blue-700 transition-all">Kirim Usulan</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProcurementModule;
