
import React from 'react';
import { 
  Users, 
  Truck, 
  Clock, 
  AlertCircle,
  TrendingUp,
  Download,
  Calendar
} from 'lucide-react';

const AdminDashboard: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tighter italic">Satu Dashboard</h2>
          <p className="text-slate-500 font-medium mt-1">Analisis kinerja & operasional KPKNL Serang</p>
        </div>
        <div className="flex gap-3">
          <button className="px-6 py-3 bg-white border border-slate-200 text-slate-600 rounded-2xl font-bold text-xs flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm">
            <Calendar className="w-4 h-4" /> Hari Ini
          </button>
          <button className="px-6 py-3 bg-blue-600 text-white rounded-2xl font-black text-xs flex items-center gap-2 hover:bg-blue-700 transition-all shadow-xl shadow-blue-500/20 active:scale-95">
            <Download className="w-4 h-4" /> Cetak Laporan
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Pegawai', value: '142', sub: 'PNS & PPNPN', icon: Users, color: 'blue' },
          { label: 'Presensi Masuk', value: '128', sub: '90.1% Hadir', icon: Clock, color: 'emerald' },
          { label: 'Telat (Menit)', value: '345', sub: '+12m dari kemarin', icon: TrendingUp, color: 'rose' },
          { label: 'Aset Kendaraan', value: '12', sub: '8 Tersedia', icon: Truck, color: 'indigo' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm group hover:scale-[1.03] transition-all">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-6 bg-${stat.color}-50 text-${stat.color}-600 group-hover:bg-${stat.color}-600 group-hover:text-white transition-all`}>
              <stat.icon className="w-6 h-6" />
            </div>
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">{stat.label}</p>
            <h3 className="text-3xl font-black text-slate-900 mt-1">{stat.value}</h3>
            <p className={`text-[10px] font-bold mt-2 text-${stat.color}-600`}>{stat.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
           <div className="p-8 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-black text-slate-900 uppercase tracking-widest text-sm">Status Kehadiran Real-time</h3>
              <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-full uppercase">Update: 10:45 AM</span>
           </div>
           <div className="p-8">
             <div className="space-y-6">
               {[
                 { name: 'Budi (Satpam)', time: '07:45', status: 'LATE', diff: '+15m' },
                 { name: 'Ahmad (Driver)', time: '07:28', status: 'ON_TIME', diff: '-2m' },
                 { name: 'Siska (HI)', time: '08:02', status: 'LATE', diff: '+32m' },
               ].map((log, i) => (
                 <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center font-bold text-slate-400">
                        {log.name.charAt(0)}
                      </div>
                      <div>
                        <p className="text-sm font-black text-slate-900">{log.name}</p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase">Check-in: {log.time}</p>
                      </div>
                    </div>
                    <div className="text-right">
                       <span className={`text-[10px] font-black px-3 py-1 rounded-lg ${log.status === 'LATE' ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'}`}>
                         {log.status}
                       </span>
                       <p className="text-[9px] font-bold text-slate-400 mt-1">{log.diff}</p>
                    </div>
                 </div>
               ))}
             </div>
           </div>
        </div>

        <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden">
           <div className="absolute top-0 right-0 p-8">
              <AlertCircle className="w-12 h-12 text-blue-500/20" />
           </div>
           <h3 className="text-xl font-black italic tracking-tighter">AI Security Insight</h3>
           <p className="text-slate-400 text-sm font-medium mt-4 leading-relaxed">
             Sistem mendeteksi 2 anomali login dari lokasi di luar Serang dalam 24 jam terakhir. 
             Akun terkait telah ditandai untuk review audit.
           </p>
           
           <div className="mt-8 space-y-4">
              <div className="p-4 bg-white/5 rounded-2xl border border-white/10 flex items-center gap-4">
                 <div className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></div>
                 <div className="text-xs font-bold">Anomali Lokasi (Teleport Detection)</div>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-white/10 flex items-center gap-4">
                 <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                 <div className="text-xs font-bold">Multi-device Login (Single App Rule)</div>
              </div>
           </div>

           <button className="mt-8 w-full py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-700 transition-all">
             Audit Security Trail
           </button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
