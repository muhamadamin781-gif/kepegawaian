
import React, { useState, useRef } from 'react';
import { 
  Search, 
  Plus, 
  UserPlus, 
  Shield, 
  Filter, 
  MoreHorizontal, 
  X, 
  Camera, 
  Phone, 
  MapPin, 
  GraduationCap, 
  DollarSign, 
  Lock, 
  User as UserIcon, 
  CheckCircle,
  Eye,
  EyeOff,
  ExternalLink,
  Award,
  TrendingUp,
  FileText,
  Download,
  Clock,
  AtSign,
  Key,
  Briefcase,
  History,
  TrendingDown,
  Calendar,
  Zap,
  Mail
} from 'lucide-react';
import { UserRole, User } from '../types';

interface EmployeeManagementProps {
  users: User[];
  onUpdateUsers: (updatedUsers: User[]) => void;
  canEditWorkHours: boolean;
}

const EmployeeManagement: React.FC<EmployeeManagementProps> = ({ users, onUpdateUsers, canEditWorkHours }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [selectedUserDetail, setSelectedUserDetail] = useState<User | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState<Partial<User>>({
    name: '', username: '', password: '', role: UserRole.PNS, baseSalary: 0, 
    address: '', education: '', phone: '', photo: '', workHours: '07:30 - 17:00', email: ''
  });

  const handleOpenAdd = () => {
    setEditingUser(null);
    setShowPassword(false);
    setFormData({ 
      name: '', username: '', password: '', role: UserRole.PNS, 
      baseSalary: 0, address: '', education: '', phone: '', photo: '', workHours: '07:30 - 17:00', email: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (u: User) => {
    setEditingUser(u);
    setShowPassword(false);
    setFormData({ ...u });
    setIsModalOpen(true);
  };

  const handleOpenDetail = (u: User) => {
    setSelectedUserDetail(u);
    setIsDetailModalOpen(true);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, photo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.username) {
        alert("Username harus diisi!");
        return;
    }
    setIsSaving(true);

    await new Promise(resolve => setTimeout(resolve, 800));

    if (editingUser) {
      onUpdateUsers(users.map(u => u.id === editingUser.id ? { ...u, ...formData } as User : u));
    } else {
      const newUser = { 
        ...formData, 
        id: Math.random().toString(36).substr(2, 9) 
      } as User;
      onUpdateUsers([newUser, ...users]);
    }

    setIsSaving(false);
    setIsModalOpen(false);
    alert(editingUser ? "Data Pegawai dan Akun Berhasil Diperbarui!" : "Akun Pegawai Baru Berhasil Dibuat!");
  };

  const formatCurrency = (val?: number) => {
    if (!val) return 'Rp 0';
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tighter italic">Manajemen SDM & Akun</h2>
          <p className="text-slate-500 text-sm font-medium">Pengelolaan data pegawai, kredensial login, dan jam kerja</p>
        </div>
        <button 
          onClick={handleOpenAdd}
          className="flex items-center gap-3 px-8 py-4 bg-blue-600 text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all hover:bg-blue-700"
        >
          <UserPlus className="w-5 h-5" /> Registrasi Pegawai Baru
        </button>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100 bg-slate-50/30 flex flex-col md:flex-row gap-4 justify-between items-center">
           <div className="relative w-full md:w-96">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input type="text" placeholder="Cari Pegawai atau Username..." className="w-full pl-14 pr-6 py-4 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all text-xs font-bold" />
           </div>
           <div className="flex gap-3">
              <button className="p-4 bg-white border border-slate-200 rounded-2xl text-slate-400 hover:text-blue-600 transition-all"><Filter className="w-5 h-5" /></button>
           </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-[10px] uppercase tracking-[0.2em] text-slate-400 font-black">
                <th className="px-10 py-6">Profil & Username</th>
                <th className="px-10 py-6">Jabatan / Role</th>
                <th className="px-10 py-6">Email Instansi</th>
                <th className="px-10 py-6">Jam Kerja</th>
                <th className="px-10 py-6">Status Login</th>
                <th className="px-10 py-6 text-right">Tindakan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id} className="group hover:bg-slate-50/50 transition-all">
                  <td className="px-10 py-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-blue-100 border-2 border-white shadow-sm flex items-center justify-center font-black text-blue-600 overflow-hidden text-center">
                        {u.photo ? <img src={u.photo} className="w-full h-full object-cover" /> : u.name.charAt(0)}
                      </div>
                      <div>
                        <p className="text-sm font-black text-slate-900">{u.name}</p>
                        <p className="text-[10px] font-black text-blue-600 mt-0.5 uppercase tracking-widest flex items-center gap-1">
                          <AtSign className="w-2.5 h-2.5" /> {u.username}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-10 py-6">
                    <span className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
                      u.role === UserRole.ADMIN || u.role === UserRole.KSBU ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      <Shield className="w-3 h-3" /> {u.role.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-10 py-6">
                    <div className="flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-slate-400" />
                      <span className="text-xs font-bold text-slate-600 italic lowercase">{u.email || '-'}</span>
                    </div>
                  </td>
                  <td className="px-10 py-6 text-xs font-black text-slate-600 italic">
                    {u.workHours || 'Belum Diatur'}
                  </td>
                  <td className="px-10 py-6">
                    <span className="inline-flex items-center gap-1.5 text-[9px] font-black text-emerald-600 bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-100 uppercase tracking-widest">
                      <CheckCircle className="w-3 h-3" /> Aktif
                    </span>
                  </td>
                  <td className="px-10 py-6 text-right">
                    <div className="flex justify-end items-center gap-2">
                      <button 
                        onClick={() => handleOpenDetail(u)}
                        className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-black transition-all"
                      >
                        <ExternalLink className="w-3.5 h-3.5" /> Info
                      </button>
                      <button 
                        onClick={() => handleOpenEdit(u)}
                        className="p-3 text-slate-300 hover:text-blue-600 hover:bg-white rounded-xl transition-all border border-transparent hover:border-slate-100"
                        title="Edit Data & Password"
                      >
                        <MoreHorizontal className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Employee Detail Modal */}
      {isDetailModalOpen && selectedUserDetail && (
        <div className="fixed inset-0 z-[110] bg-slate-900/70 backdrop-blur-lg flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-5xl rounded-[3rem] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-8 duration-500 flex flex-col max-h-[90vh]">
            <div className="p-8 bg-slate-900 text-white flex justify-between items-center relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <Shield className="w-32 h-32" />
              </div>
              <div className="flex items-center gap-6 relative z-10">
                <div className="w-20 h-20 rounded-[1.5rem] bg-blue-600 border-4 border-slate-800 overflow-hidden flex items-center justify-center text-3xl font-black">
                  {selectedUserDetail.photo ? <img src={selectedUserDetail.photo} className="w-full h-full object-cover" /> : selectedUserDetail.name.charAt(0)}
                </div>
                <div>
                  <h3 className="text-3xl font-black italic tracking-tighter">{selectedUserDetail.name}</h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-[10px] font-black uppercase tracking-widest text-blue-400">@{selectedUserDetail.username}</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-600"></span>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">NIP: {selectedUserDetail.nip || '-'}</span>
                  </div>
                </div>
              </div>
              <button onClick={() => setIsDetailModalOpen(false)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all relative z-10">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-8 grid grid-cols-1 lg:grid-cols-3 gap-8 bg-slate-50/50">
              {/* Left Column: Personal Info */}
              <div className="space-y-6">
                <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm space-y-6">
                  <h4 className="text-xs font-black uppercase tracking-widest text-slate-900 flex items-center gap-2">
                    <UserIcon className="w-4 h-4 text-blue-600" /> Profil Pegawai
                  </h4>
                  <div className="space-y-4">
                    <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-2xl">
                      <Mail className="w-4 h-4 text-slate-400 mt-1" />
                      <div>
                        <p className="text-[9px] font-black text-slate-400 uppercase">Email</p>
                        <p className="text-sm font-bold text-slate-800 italic lowercase">{selectedUserDetail.email || 'Email belum diinput'}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-2xl">
                      <Phone className="w-4 h-4 text-slate-400 mt-1" />
                      <div>
                        <p className="text-[9px] font-black text-slate-400 uppercase">Kontak</p>
                        <p className="text-sm font-bold text-slate-800">{selectedUserDetail.phone || 'Tidak Tersedia'}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-2xl">
                      <MapPin className="w-4 h-4 text-slate-400 mt-1" />
                      <div>
                        <p className="text-[9px] font-black text-slate-400 uppercase">Alamat</p>
                        <p className="text-sm font-bold text-slate-800 leading-relaxed italic">{selectedUserDetail.address || 'Alamat belum diinput'}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-2xl">
                      <GraduationCap className="w-4 h-4 text-slate-400 mt-1" />
                      <div>
                        <p className="text-[9px] font-black text-slate-400 uppercase">Pendidikan</p>
                        <p className="text-sm font-bold text-slate-800">{selectedUserDetail.education || '-'}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-2xl">
                      <Briefcase className="w-4 h-4 text-slate-400 mt-1" />
                      <div>
                        <p className="text-[9px] font-black text-slate-400 uppercase">Seksi / Penempatan</p>
                        <p className="text-sm font-bold text-slate-800">{selectedUserDetail.section || '-'}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Middle & Right Column: Career, Salary, and Training */}
              <div className="lg:col-span-2 space-y-6">
                {/* Salary Section */}
                <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm">
                  <div className="flex items-center justify-between mb-8">
                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-900 flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-emerald-600" /> Kesejahteraan & Kenaikan Gaji
                    </h4>
                    <div className="px-4 py-1.5 bg-emerald-50 text-emerald-600 rounded-full text-[9px] font-black uppercase tracking-widest">
                      KGB Terjadwal
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="p-6 bg-slate-900 rounded-[2rem] text-white flex flex-col justify-center">
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Gaji Pokok Saat Ini</p>
                       <h5 className="text-2xl font-black italic tracking-tighter mt-1">{formatCurrency(selectedUserDetail.baseSalary)}</h5>
                       <div className="mt-4 flex items-center gap-2 text-emerald-400 text-[10px] font-bold">
                          <TrendingUp className="w-3 h-3" /> +3% dari tahun sebelumnya
                       </div>
                    </div>
                    <div className="p-6 bg-blue-50 border border-blue-100 rounded-[2rem] flex flex-col justify-center">
                       <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Estimasi KGB Berikutnya</p>
                       <h5 className="text-xl font-black italic tracking-tighter mt-1 text-slate-900">{selectedUserDetail.nextSalaryIncrease || '01 Januari 2026'}</h5>
                       <p className="mt-2 text-[10px] font-medium text-slate-500 leading-tight">
                         Kenaikan Gaji Berkala otomatis diproses oleh sistem per 2 tahun masa kerja.
                       </p>
                    </div>
                  </div>

                  <div className="mt-8 space-y-4">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Riwayat Perubahan Gaji</p>
                    {(selectedUserDetail.salaryHistory || [
                      { id: '1', description: 'Kenaikan Gaji Berkala 2024', effectiveDate: '01/01/2024', amount: (selectedUserDetail.baseSalary || 0) },
                      { id: '2', description: 'Penyesuaian Gaji Pokok Nasional', effectiveDate: '15/05/2023', amount: (selectedUserDetail.baseSalary || 0) * 0.95 }
                    ]).map(item => (
                      <div key={item.id} className="flex items-center justify-between p-4 border border-slate-100 rounded-2xl hover:bg-slate-50 transition-colors">
                        <div className="flex items-center gap-4">
                           <div className="p-2 bg-emerald-50 rounded-lg"><TrendingUp className="w-4 h-4 text-emerald-600" /></div>
                           <div>
                              <p className="text-sm font-black text-slate-800 italic">{item.description}</p>
                              <p className="text-[9px] font-bold text-slate-400 uppercase mt-0.5">{item.effectiveDate}</p>
                           </div>
                        </div>
                        <p className="text-sm font-black text-slate-900">{formatCurrency(item.amount)}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Training History Section */}
                <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm">
                  <div className="flex items-center justify-between mb-8">
                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-900 flex items-center gap-2">
                      <Award className="w-5 h-5 text-amber-500" /> Riwayat Diklat & Kompetensi
                    </h4>
                    <span className="text-[10px] font-black text-slate-400">Total: {(selectedUserDetail.trainingHistory?.length || 2)} Diklat</span>
                  </div>

                  <div className="space-y-4">
                    {(selectedUserDetail.trainingHistory || [
                      { id: 'd1', name: 'Diklat Teknis Pengelolaan BMN', date: 'Maret 2024', hours: '40 JP' },
                      { id: 'd2', name: 'Workshop Pengarusutamaan Gender', date: 'Desember 2023', hours: '12 JP' }
                    ]).map(diklat => (
                      <div key={diklat.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-5 bg-slate-50 rounded-2xl border border-transparent hover:border-amber-200 hover:bg-white transition-all group gap-4">
                        <div className="flex gap-4">
                           <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center border border-slate-200 shadow-sm">
                              <FileText className="w-5 h-5 text-slate-400 group-hover:text-amber-500 transition-colors" />
                           </div>
                           <div>
                              <p className="text-sm font-black text-slate-900 italic">{diklat.name}</p>
                              <div className="flex items-center gap-2 mt-1">
                                 <Calendar className="w-3 h-3 text-slate-400" />
                                 <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{diklat.date}</span>
                              </div>
                           </div>
                        </div>
                        <div className="flex items-center gap-4">
                           <div className="text-right">
                              <p className="text-xs font-black text-slate-800">{diklat.hours}</p>
                              <p className="text-[8px] font-bold text-emerald-600 uppercase tracking-widest">Sertifikat Tersedia</p>
                           </div>
                           <button className="p-2.5 bg-white rounded-xl border border-slate-200 text-blue-600 hover:bg-blue-600 hover:text-white transition-all shadow-sm">
                             <Download className="w-4 h-4" />
                           </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-8 p-6 bg-slate-900 rounded-[2rem] text-white flex items-center justify-between">
                     <div className="flex items-center gap-4">
                        <Zap className="w-5 h-5 text-amber-400 fill-amber-400" />
                        <div>
                           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Poin Kompetensi</p>
                           <h6 className="text-xl font-black italic tracking-tighter">84.5 / 100</h6>
                        </div>
                     </div>
                     <button className="px-6 py-3 bg-white/10 hover:bg-white/20 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">Input Diklat Baru</button>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-8 bg-white border-t border-slate-100 flex justify-end gap-4">
              <button 
                onClick={() => setIsDetailModalOpen(false)}
                className="px-10 py-4 bg-slate-100 text-slate-600 rounded-[2rem] font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
              >
                Tutup Informasi
              </button>
              <button 
                onClick={() => {
                  setIsDetailModalOpen(false);
                  handleOpenEdit(selectedUserDetail);
                }}
                className="px-10 py-4 bg-blue-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all"
              >
                Edit Data Pegawai
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Account Creation/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-4xl rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 flex flex-col max-h-[90vh]">
            <div className="p-8 bg-slate-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-black italic tracking-tighter">{editingUser ? 'Manajemen Akun Pegawai' : 'Registrasi Pegawai Baru'}</h3>
                <p className="text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em] mt-1">Konfigurasi Hak Akses & Kredensial SATU KPKNL</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-all"><X className="w-5 h-5" /></button>
            </div>
            
            <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-10 space-y-10 bg-white">
              <div className="flex flex-col md:flex-row gap-10">
                <div className="w-full md:w-1/3 flex flex-col items-center space-y-6">
                  <div 
                    onClick={triggerFileInput}
                    className="relative group w-48 h-48 rounded-[3rem] bg-slate-100 border-4 border-white shadow-xl flex items-center justify-center overflow-hidden cursor-pointer active:scale-95 transition-transform"
                  >
                    {formData.photo ? (
                      <img src={formData.photo} className="w-full h-full object-cover" />
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <UserIcon className="w-16 h-16 text-slate-300" />
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Pilih Foto</span>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                      <Camera className="w-8 h-8 text-white" />
                      <span className="text-white text-[10px] font-black uppercase tracking-widest">Ganti Foto</span>
                    </div>
                  </div>
                  <input type="file" ref={fileInputRef} accept="image/*" className="hidden" onChange={handlePhotoUpload} />

                  <div className="w-full p-6 bg-blue-50 rounded-[2rem] border border-blue-100 space-y-4">
                    <h4 className="text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center gap-2">
                      <Shield className="w-3 h-3" /> Status Kepegawaian
                    </h4>
                    <div className="space-y-2">
                       <label className="text-[9px] font-bold text-slate-400 uppercase">Role / Akses</label>
                       <select className="w-full px-4 py-3 bg-white border-2 border-slate-100 rounded-xl outline-none text-xs font-black text-slate-800" value={formData.role} onChange={e => setFormData({...formData, role: e.target.value as UserRole})}>
                          {Object.values(UserRole).map(role => <option key={role} value={role}>{role.replace('_', ' ')}</option>)}
                       </select>
                    </div>
                  </div>
                </div>

                <div className="flex-1 space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nama Lengkap</label>
                      <input required className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold transition-all italic" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-2">
                        <AtSign className="w-3 h-3 text-blue-600" /> Username Akun
                      </label>
                      <input required className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-black text-blue-700 transition-all" value={formData.username} onChange={e => setFormData({...formData, username: e.target.value})} />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-2">
                        <Key className="w-3 h-3 text-rose-500" /> Kata Sandi Baru
                      </label>
                      <div className="relative">
                         <input 
                          type={showPassword ? "text" : "password"} 
                          placeholder={editingUser ? "Kosongkan jika tidak ganti" : "Set kata sandi..."} 
                          className="w-full pl-6 pr-12 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-rose-500 outline-none text-sm font-bold transition-all" 
                          value={formData.password} 
                          onChange={e => setFormData({...formData, password: e.target.value})} 
                         />
                         <button 
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-blue-600 transition-colors"
                         >
                           {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                         </button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-2">
                        <Clock className="w-3 h-3 text-blue-600" /> Jam Kerja / Shift
                      </label>
                      <input 
                        required 
                        className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold transition-all" 
                        value={formData.workHours} 
                        onChange={e => setFormData({...formData, workHours: e.target.value})} 
                        placeholder="07:30 - 17:00"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-blue-600" /> Email Instansi
                      </label>
                      <input type="email" className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold transition-all lowercase" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} placeholder="pegawai@kpknl.go.id" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nomor HP</label>
                      <input className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold transition-all" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Pendidikan</label>
                      <input className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold transition-all" value={formData.education} onChange={e => setFormData({...formData, education: e.target.value})} />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Gaji Pokok (Simulation Only)</label>
                      <input type="number" className="w-full px-5 py-4 bg-blue-50 border-2 border-blue-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-black text-blue-900" value={formData.baseSalary} onChange={e => setFormData({...formData, baseSalary: parseInt(e.target.value) || 0})} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-10 flex gap-4 border-t border-slate-100">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)} 
                  className="flex-1 py-5 bg-slate-100 text-slate-500 rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] hover:bg-slate-200 transition-all"
                >
                  Batal
                </button>
                <button 
                  type="submit" 
                  disabled={isSaving}
                  className="flex-1 py-5 bg-blue-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-blue-500/30 hover:bg-blue-700 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isSaving ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" /> Simpan Perubahan Akun
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeManagement;
