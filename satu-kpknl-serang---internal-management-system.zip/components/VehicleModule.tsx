
import React, { useState, useRef } from 'react';
import { 
  Truck, 
  Car, 
  Bike, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  Camera, 
  X, 
  Image as ImageIcon, 
  Wrench, 
  User, 
  Download, 
  FileText, 
  Table as TableIcon,
  CheckCircle,
  History,
  Calendar,
  ChevronRight,
  Briefcase,
  MapPin,
  ClipboardList,
  Send
} from 'lucide-react';
import { VehicleType, VehicleStatus, Vehicle, UserRole, MaintenanceInfo } from '../types';

const INITIAL_VEHICLES: Vehicle[] = [
  { id: '1', name: 'Toyota Innova Reborn', plateNumber: 'A 1234 XX', status: VehicleStatus.AVAILABLE, type: VehicleType.CAR, category: 'OPERATIONAL', photo: 'https://images.unsplash.com/photo-1590362891991-f776e747a588?auto=format&fit=crop&q=80&w=400' },
  { id: '2', name: 'Toyota Hiace Commuter', plateNumber: 'A 5678 YY', status: VehicleStatus.BORROWED, type: VehicleType.CAR, category: 'OPERATIONAL', photo: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80&w=400', borrower: 'Ahmad Faisal' },
  { id: '3', name: 'Toyota Fortuner', plateNumber: 'A 1 RI', status: VehicleStatus.AVAILABLE, type: VehicleType.CAR, category: 'HEAD_OFFICE', photo: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=400' },
];

const MOCK_HISTORY = [
  { id: 'h1', vehicle: 'Toyota Innova Reborn', plate: 'A 1234 XX', borrower: 'Siti Rohimah', purpose: 'Perjalanan Dinas ke Kanwil', date: '2024-05-20', time: '08:00 - 16:00' },
  { id: 'h2', vehicle: 'Toyota Hiace Commuter', plate: 'A 5678 YY', borrower: 'Ahmad Faisal', purpose: 'Sosialisasi PKN', date: '2024-05-21', time: '07:30 - 14:00' },
  { id: 'h3', vehicle: 'Isuzu Elf Logistik', plate: 'A 9012 ZZ', borrower: 'Supardi', purpose: 'Pengangkutan Berkas Lelang', date: '2024-05-19', time: '09:00 - 12:00' },
  { id: 'h4', vehicle: 'Toyota Fortuner', plate: 'A 1 RI', borrower: 'Kepala Kantor', purpose: 'Rapat Koordinasi DJKN', date: '2024-05-22', time: '10:00 - 18:00' },
];

const VehicleModule: React.FC<{ userRole?: UserRole }> = ({ userRole }) => {
  const [vehicles, setVehicles] = useState<Vehicle[]>(INITIAL_VEHICLES);
  const [isFormOpen, setFormOpen] = useState(false);
  const [isHistoryOpen, setHistoryOpen] = useState(false);
  const [isSendMaintenanceModalOpen, setSendMaintenanceModalOpen] = useState(false);
  const [isFinishMaintenanceModalOpen, setFinishMaintenanceModalOpen] = useState(false);
  const [activeVehicleId, setActiveVehicleId] = useState<string | null>(null);
  
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [formData, setFormData] = useState<Partial<Vehicle>>({ 
    name: '', plateNumber: '', type: VehicleType.CAR, status: VehicleStatus.AVAILABLE, category: 'OPERATIONAL', photo: '' 
  });

  const [maintData, setMaintData] = useState<Partial<MaintenanceInfo>>({
    senderName: '', workshopName: '', workshopAddress: '', repairedItems: ''
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleOpenAdd = () => {
    setEditingVehicle(null);
    setFormData({ name: '', plateNumber: '', type: VehicleType.CAR, status: VehicleStatus.AVAILABLE, category: 'OPERATIONAL', photo: '' });
    setFormOpen(true);
  };

  const handleEdit = (v: Vehicle) => {
    setEditingVehicle(v);
    setFormData({ ...v });
    setFormOpen(true);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, photo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const openSendToMaintenance = (vId: string) => {
    setActiveVehicleId(vId);
    setMaintData({ senderName: '', workshopName: '', workshopAddress: '' });
    setSendMaintenanceModalOpen(true);
  };

  const openFinishMaintenance = (vId: string) => {
    setActiveVehicleId(vId);
    setMaintData({ repairedItems: '' });
    setFinishMaintenanceModalOpen(true);
  };

  const confirmSendMaintenance = (e: React.FormEvent) => {
    e.preventDefault();
    setVehicles(prev => prev.map(v => {
      if (v.id === activeVehicleId) {
        return { 
          ...v, 
          status: VehicleStatus.MAINTENANCE, 
          maintenanceInfo: maintData as MaintenanceInfo 
        };
      }
      return v;
    }));
    setSendMaintenanceModalOpen(false);
    setActiveVehicleId(null);
  };

  const confirmFinishMaintenance = (e: React.FormEvent) => {
    e.preventDefault();
    setVehicles(prev => prev.map(v => {
      if (v.id === activeVehicleId) {
        // Record log or perform action with repairedItems here if needed
        return { 
          ...v, 
          status: VehicleStatus.AVAILABLE, 
          maintenanceInfo: undefined 
        };
      }
      return v;
    }));
    setFinishMaintenanceModalOpen(false);
    setActiveVehicleId(null);
    alert("Maintenance Selesai! Kendaraan kini tersedia di Pool.");
  };

  const handleDelete = (id: string) => {
    if(confirm("Hapus kendaraan dari sistem?")) {
      setVehicles(prev => prev.filter(v => v.id !== id));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingVehicle) {
      setVehicles(prev => prev.map(v => v.id === editingVehicle.id ? { ...v, ...formData } as Vehicle : v));
    } else {
      setVehicles(prev => [...prev, { ...formData, id: Math.random().toString(36).substr(2, 9) } as Vehicle]);
    }
    setFormOpen(false);
  };

  const handleDownloadReport = (format: 'excel' | 'pdf') => {
    alert(`Mengekspor Laporan Riwayat Peminjaman Kendaraan (${format.toUpperCase()})...`);
  };

  const canManageMaintenance = userRole === UserRole.ADMIN || userRole === UserRole.DRIVER;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tighter italic">Kelola Armada</h2>
          <p className="text-slate-500 font-medium mt-1">Sistem Administrasi dan Monitoring Aset Kendaraan Dinas</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button 
            onClick={() => setHistoryOpen(true)}
            className="px-6 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-black transition-all shadow-lg shadow-slate-900/10"
          >
            <History className="w-4 h-4" /> Laporan Riwayat
          </button>
          <button 
            onClick={handleOpenAdd}
            className="flex items-center justify-center gap-3 px-8 py-4 bg-blue-600 text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-500/20 transition-all hover:bg-blue-700 active:scale-95"
          >
            <Plus className="w-5 h-5" /> Tambah Armada
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {vehicles.map((v) => (
          <div key={v.id} className="group bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden shadow-sm hover:shadow-2xl transition-all flex flex-col">
            <div className="relative h-56">
              <img src={v.photo || 'https://via.placeholder.com/400x300'} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
              <div className="absolute top-4 left-4">
                 <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border-2 shadow-lg backdrop-blur bg-white/90 ${
                   v.category === 'HEAD_OFFICE' ? 'border-amber-500 text-amber-600' : 'border-blue-500 text-blue-600'
                 }`}>
                   {v.category.replace('_', ' ')}
                 </span>
              </div>
              <div className="absolute top-4 right-4 flex gap-2">
                 <button onClick={() => handleEdit(v)} className="p-2.5 bg-white/20 backdrop-blur text-white rounded-xl hover:bg-white hover:text-blue-600 transition-all">
                    <Edit3 className="w-4 h-4" />
                 </button>
                 <button onClick={() => handleDelete(v.id)} className="p-2.5 bg-rose-500/20 backdrop-blur text-white rounded-xl hover:bg-rose-500 transition-all">
                    <Trash2 className="w-4 h-4" />
                 </button>
              </div>
              <div className="absolute bottom-6 left-6">
                <h4 className="text-white font-black text-xl italic tracking-tighter">{v.name}</h4>
                <p className="text-white/70 text-[10px] font-bold uppercase tracking-[0.2em] mt-0.5">{v.plateNumber}</p>
              </div>
            </div>

            <div className="p-8 flex-1 flex flex-col space-y-6">
              <div className="flex justify-between items-center">
                 <div className="flex items-center gap-2">
                    {v.type === VehicleType.CAR ? <Car className="w-4 h-4 text-slate-400" /> : <Bike className="w-4 h-4 text-slate-400" />}
                    <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{v.type}</span>
                 </div>
                 <span className={`text-[10px] font-black uppercase px-4 py-1.5 rounded-full ${
                   v.status === VehicleStatus.AVAILABLE ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                   v.status === VehicleStatus.BORROWED ? 'bg-rose-50 text-rose-600 border border-rose-100' :
                   'bg-amber-50 text-amber-600 border border-amber-100'
                 }`}>
                   {v.status}
                 </span>
              </div>

              {v.status === VehicleStatus.BORROWED ? (
                <div className="p-5 bg-rose-50 rounded-2xl border border-rose-100 flex items-center gap-4">
                   <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center border border-rose-100 shadow-sm">
                      <User className="w-5 h-5 text-rose-500" />
                   </div>
                   <div>
                      <p className="text-[9px] font-black text-rose-400 uppercase tracking-widest">Dipakai Oleh:</p>
                      <p className="text-xs font-black text-rose-900">{v.borrower || 'User Sistem'}</p>
                   </div>
                </div>
              ) : v.status === VehicleStatus.MAINTENANCE ? (
                <div className="p-5 bg-amber-50 rounded-2xl border border-amber-100 space-y-3">
                   <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center border border-amber-100 shadow-sm">
                          <Wrench className="w-5 h-5 text-amber-500" />
                      </div>
                      <div>
                          <p className="text-[9px] font-black text-amber-400 uppercase tracking-widest">Sedang Maintenance</p>
                          <p className="text-xs font-black text-amber-900">{v.maintenanceInfo?.workshopName || 'Bengkel Rekanan'}</p>
                      </div>
                   </div>
                   <div className="pt-2 border-t border-amber-200/50 flex items-start gap-2">
                      <MapPin className="w-3 h-3 text-amber-500 shrink-0 mt-0.5" />
                      <p className="text-[10px] font-medium text-amber-700 leading-tight italic">{v.maintenanceInfo?.workshopAddress}</p>
                   </div>
                </div>
              ) : (
                <div className="p-5 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center gap-4">
                   <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center border border-emerald-100 shadow-sm">
                      <CheckCircle className="w-5 h-5 text-emerald-500" />
                   </div>
                   <div>
                      <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">Status Pool:</p>
                      <p className="text-xs font-black text-emerald-900">Unit Siap Digunakan</p>
                   </div>
                </div>
              )}

              {canManageMaintenance && (
                <button 
                  onClick={() => v.status === VehicleStatus.MAINTENANCE ? openFinishMaintenance(v.id) : openSendToMaintenance(v.id)}
                  className={`mt-auto w-full py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${
                    v.status === VehicleStatus.MAINTENANCE 
                    ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-500/20' 
                    : 'bg-slate-900 text-white hover:bg-black shadow-lg shadow-slate-500/20'
                  }`}
                >
                  <Wrench className="w-4 h-4" />
                  {v.status === VehicleStatus.MAINTENANCE ? 'Selesai Perbaikan' : 'Kirim ke Bengkel'}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* History Report Modal */}
      {isHistoryOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-4">
           <div className="bg-white w-full max-w-5xl rounded-[3rem] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-8 duration-500 flex flex-col max-h-[85vh]">
              <div className="p-8 bg-slate-900 text-white flex justify-between items-center">
                 <div className="flex items-center gap-4">
                    <div className="p-3 bg-white/10 rounded-2xl"><History className="w-6 h-6" /></div>
                    <div>
                       <h3 className="text-2xl font-black italic tracking-tighter">Laporan Riwayat Kendaraan</h3>
                       <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-1">Rekapitulasi penggunaan aset armada</p>
                    </div>
                 </div>
                 <div className="flex gap-2">
                    <button 
                      onClick={() => handleDownloadReport('excel')}
                      className="p-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-all flex items-center gap-2 text-[10px] font-black uppercase"
                    >
                      <TableIcon className="w-4 h-4" /> Excel
                    </button>
                    <button 
                      onClick={() => handleDownloadReport('pdf')}
                      className="p-3 bg-rose-600 text-white rounded-xl hover:bg-rose-700 transition-all flex items-center gap-2 text-[10px] font-black uppercase"
                    >
                      <FileText className="w-4 h-4" /> PDF
                    </button>
                    <button onClick={() => setHistoryOpen(false)} className="p-3 bg-white/10 rounded-xl hover:bg-white/20 transition-all"><X className="w-5 h-5" /></button>
                 </div>
              </div>

              <div className="flex-1 overflow-y-auto p-0">
                 <div className="p-8 border-b border-slate-100 flex flex-col md:flex-row gap-4 items-center justify-between">
                    <div className="relative w-full md:w-96">
                       <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                       <input type="text" placeholder="Cari Nama Peminjam atau Kendaraan..." className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 text-xs font-bold" />
                    </div>
                    <div className="flex gap-3">
                       <input type="date" className="px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-black uppercase text-slate-600" />
                       <button className="px-6 py-3 bg-slate-100 text-slate-600 rounded-xl text-[10px] font-black uppercase">Filter</button>
                    </div>
                 </div>

                 <div className="overflow-x-auto">
                    <table className="w-full text-left">
                       <thead>
                          <tr className="bg-slate-50 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
                             <th className="px-10 py-6">Peminjam</th>
                             <th className="px-10 py-6">Kendaraan</th>
                             <th className="px-10 py-6">Waktu</th>
                             <th className="px-10 py-6">Keperluan</th>
                          </tr>
                       </thead>
                       <tbody className="divide-y divide-slate-100">
                          {MOCK_HISTORY.map((h) => (
                             <tr key={h.id} className="hover:bg-slate-50/50 transition-all">
                                <td className="px-10 py-6">
                                   <div className="flex items-center gap-4">
                                      <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center font-black text-xs">{h.borrower.charAt(0)}</div>
                                      <p className="text-sm font-black text-slate-900">{h.borrower}</p>
                                   </div>
                                </td>
                                <td className="px-10 py-6">
                                   <p className="text-sm font-black text-slate-800">{h.vehicle}</p>
                                   <p className="text-[10px] font-bold text-slate-400 uppercase">{h.plate}</p>
                                </td>
                                <td className="px-10 py-6">
                                   <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
                                      <Calendar className="w-3 h-3 text-slate-400" /> {h.date}
                                   </div>
                                   <p className="text-[10px] font-black text-slate-400 mt-1">{h.time}</p>
                                </td>
                                <td className="px-10 py-6">
                                   <div className="flex items-center gap-2 text-[11px] font-medium text-slate-500 italic max-w-xs">
                                      <Briefcase className="w-3 h-3 shrink-0" /> {h.purpose}
                                   </div>
                                </td>
                             </tr>
                          ))}
                       </tbody>
                    </table>
                 </div>
              </div>
              <div className="p-6 bg-slate-50 text-center border-t border-slate-100">
                 <button className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline">Tampilkan Lebih Banyak Riwayat</button>
              </div>
           </div>
        </div>
      )}

      {/* Send to Maintenance Modal */}
      {isSendMaintenanceModalOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
           <div className="bg-white w-full max-w-lg rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="p-8 bg-amber-500 text-white flex justify-between items-center">
                 <div>
                    <h3 className="text-2xl font-black italic tracking-tighter">Kirim ke Bengkel</h3>
                    <p className="text-amber-100 text-[10px] font-bold uppercase tracking-widest mt-1">Registrasi Maintenance Aset</p>
                 </div>
                 <button onClick={() => setSendMaintenanceModalOpen(false)} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-all"><X className="w-6 h-6" /></button>
              </div>
              <form onSubmit={confirmSendMaintenance} className="p-10 space-y-6">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nama Pengirim</label>
                    <div className="relative">
                       <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                       <input required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-amber-500 outline-none text-sm font-bold" value={maintData.senderName} onChange={e => setMaintData({...maintData, senderName: e.target.value})} placeholder="Nama Driver / Admin..." />
                    </div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nama Bengkel</label>
                    <div className="relative">
                       <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                       <input required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-amber-500 outline-none text-sm font-bold" value={maintData.workshopName} onChange={e => setMaintData({...maintData, workshopName: e.target.value})} placeholder="Contoh: Bengkel Resmi Toyota Serang" />
                    </div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Alamat Bengkel</label>
                    <div className="relative">
                       <MapPin className="absolute left-4 top-4 w-4 h-4 text-slate-300" />
                       <textarea required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-amber-500 outline-none text-sm font-bold min-h-[100px]" value={maintData.workshopAddress} onChange={e => setMaintData({...maintData, workshopAddress: e.target.value})} placeholder="Jl. Raya Serang No. 123..." />
                    </div>
                 </div>
                 <button type="submit" className="w-full py-5 bg-amber-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-amber-500/20 hover:bg-amber-700 transition-all flex items-center justify-center gap-2">
                    <Send className="w-4 h-4" /> Konfirmasi Pengiriman
                 </button>
              </form>
           </div>
        </div>
      )}

      {/* Finish Maintenance Modal */}
      {isFinishMaintenanceModalOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
           <div className="bg-white w-full max-w-lg rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="p-8 bg-emerald-600 text-white flex justify-between items-center">
                 <div>
                    <h3 className="text-2xl font-black italic tracking-tighter">Selesai Perbaikan</h3>
                    <p className="text-emerald-100 text-[10px] font-bold uppercase tracking-widest mt-1">Dokumentasi hasil maintenance</p>
                 </div>
                 <button onClick={() => setFinishMaintenanceModalOpen(false)} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-all"><X className="w-6 h-6" /></button>
              </div>
              <form onSubmit={confirmFinishMaintenance} className="p-10 space-y-6">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Deskripsi Perbaikan / Part Diganti</label>
                    <div className="relative">
                       <ClipboardList className="absolute left-4 top-4 w-4 h-4 text-slate-300" />
                       <textarea required className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-emerald-500 outline-none text-sm font-bold min-h-[150px]" value={maintData.repairedItems} onChange={e => setMaintData({...maintData, repairedItems: e.target.value})} placeholder="Sebutkan item yang diperbaiki (contoh: Ganti Oli, Filter Udara, Spooring)..." />
                    </div>
                 </div>
                 <p className="text-[10px] text-slate-400 font-bold italic text-center px-4">
                    Data ini akan dicatat ke dalam riwayat pemeliharaan aset secara otomatis.
                 </p>
                 <button type="submit" className="w-full py-5 bg-emerald-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-emerald-500/20 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2">
                    <CheckCircle className="w-4 h-4" /> Simpan & Selesaikan
                 </button>
              </form>
           </div>
        </div>
      )}

      {isFormOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-8 bg-slate-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-black italic tracking-tighter">{editingVehicle ? 'Edit Data Armada' : 'Registrasi Armada Baru'}</h3>
                <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-1">Satu KPKNL Serang Asset Management</p>
              </div>
              <button onClick={() => setFormOpen(false)} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-all"><X className="w-6 h-6" /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-10 space-y-10 bg-white overflow-y-auto max-h-[80vh]">
              <div className="flex flex-col md:flex-row gap-10">
                {/* Photo Upload Area */}
                <div className="w-full md:w-1/3 flex flex-col items-center space-y-4">
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="relative group w-48 h-48 rounded-[2.5rem] bg-slate-100 border-4 border-white shadow-xl flex items-center justify-center overflow-hidden cursor-pointer active:scale-95 transition-transform"
                  >
                    {formData.photo ? (
                      <img src={formData.photo} className="w-full h-full object-cover" />
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <ImageIcon className="w-12 h-12 text-slate-300" />
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Pilih Foto</span>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                      <Camera className="w-8 h-8 text-white" />
                      <span className="text-white text-[10px] font-black uppercase tracking-widest">Unggah Foto</span>
                    </div>
                  </div>
                  <input type="file" ref={fileInputRef} accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                </div>

                <div className="flex-1 space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nama Kendaraan</label>
                    <input required placeholder="Contoh: Toyota Innova Zenix" className="w-full px-6 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nomor Polisi</label>
                      <input required placeholder="A 1234 B" className="w-full px-6 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none text-sm font-bold uppercase" value={formData.plateNumber} onChange={e => setFormData({...formData, plateNumber: e.target.value})} />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Jenis</label>
                      <select className="w-full px-6 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none text-sm font-bold" value={formData.type} onChange={e => setFormData({...formData, type: e.target.value as VehicleType})}>
                        <option value={VehicleType.CAR}>Mobil</option>
                        <option value={VehicleType.MOTORCYCLE}>Motor</option>
                        <option value={VehicleType.TRUCK}>Truk / Bus</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Status Peruntukan</label>
                    <select className="w-full px-6 py-4 bg-blue-50 border-2 border-blue-100 rounded-2xl outline-none text-sm font-black text-blue-900" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value as any})}>
                      <option value="OPERATIONAL">Unit Operasional Umum</option>
                      <option value="HEAD_OFFICE">Khusus Kepala Kantor</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="flex gap-4 pt-4 border-t border-slate-100">
                <button type="button" onClick={() => setFormOpen(false)} className="flex-1 py-5 font-black text-slate-400 bg-slate-100 rounded-[2rem] hover:bg-slate-200 uppercase tracking-widest text-xs transition-all">Batalkan</button>
                <button type="submit" className="flex-1 py-5 font-black text-white bg-blue-600 rounded-[2rem] shadow-2xl shadow-blue-500/30 hover:bg-blue-700 uppercase tracking-widest text-xs transition-all active:scale-95">Simpan Perubahan</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default VehicleModule;
