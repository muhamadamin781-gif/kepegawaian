
import React, { useState } from 'react';
import { ShieldCheck, User, Lock, ArrowLeft, ChevronRight, Fingerprint, Mail, RefreshCcw, Eye, EyeOff } from 'lucide-react';
import { UserRole, User as UserType } from '../types';

interface LoginProps {
  users: UserType[];
  onLogin: (u: UserType) => void;
  onCancel: () => void;
}

const Login: React.FC<LoginProps> = ({ users, onLogin, onCancel }) => {
  const [view, setView] = useState<'LOGIN' | 'FORGOT'>('LOGIN');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSumbit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const foundUser = users.find(u => 
      (u.username === username || (u.nip && u.nip === username)) && 
      u.password === password
    );

    if (foundUser) {
      onLogin(foundUser);
    } else {
      setError('Username atau Kata Sandi salah.');
    }
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    const foundUser = users.find(u => u.email === email || u.username === email);
    if (foundUser) {
      setSuccess(`Link reset kata sandi telah dikirim ke email pegawai: ${foundUser.email || 'email@instansi.go.id'}`);
      setTimeout(() => setView('LOGIN'), 3000);
    } else {
      setError('Akun tidak ditemukan dalam database kami.');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/98 backdrop-blur-xl z-[100] flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
        
        <div className="p-10 flex flex-col items-center">
          <div className="bg-blue-600 p-4 rounded-3xl mb-6 shadow-xl shadow-blue-500/20">
            <Fingerprint className="w-10 h-10 text-white" />
          </div>
          
          <h2 className="text-3xl font-black italic tracking-tighter text-slate-900">
            {view === 'LOGIN' ? 'Masuk Sistem' : 'Reset Akses'}
          </h2>
          <p className="text-slate-500 font-medium text-sm mt-2 text-center">
            {view === 'LOGIN' ? 'Portal Terintegrasi SATU KPKNL' : 'Masukkan email/username untuk pemulihan'}
          </p>

          <div className="w-full mt-10">
            {view === 'LOGIN' ? (
              <form onSubmit={handleSumbit} className="space-y-6">
                {error && (
                  <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl text-xs font-bold text-rose-600 animate-shake">
                    {error}
                  </div>
                )}
                
                <div className="space-y-4">
                  <div className="relative group">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-blue-600 transition-colors" />
                    <input 
                      type="text" 
                      placeholder="Username / NIP"
                      required
                      className="w-full pl-12 pr-4 py-5 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-blue-500 transition-all font-bold text-sm"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                    />
                  </div>

                  <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-blue-600 transition-colors" />
                    <input 
                      type={showPassword ? "text" : "password"} 
                      placeholder="Kata Sandi"
                      required
                      className="w-full pl-12 pr-12 py-5 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-blue-500 transition-all font-bold text-sm"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-blue-600 transition-colors focus:outline-none"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <button className="w-full py-5 bg-blue-600 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-2xl shadow-blue-600/30 hover:bg-blue-700 transition-all active:scale-95 flex items-center justify-center gap-3">
                  MASUK SEKARANG <ChevronRight className="w-5 h-5" />
                </button>

                <div className="text-center">
                  <button 
                    type="button"
                    onClick={() => setView('FORGOT')}
                    className="text-xs font-black text-blue-600 uppercase tracking-widest hover:underline"
                  >
                    Lupa Akun / Password?
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleResetPassword} className="space-y-6">
                {error && <div className="p-4 bg-rose-50 text-rose-600 rounded-2xl text-xs font-bold">{error}</div>}
                {success && <div className="p-4 bg-emerald-50 text-emerald-600 rounded-2xl text-xs font-bold leading-relaxed">{success}</div>}
                
                <div className="relative group">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-blue-600 transition-colors" />
                  <input 
                    type="text" 
                    placeholder="Email Pegawai atau Username"
                    required
                    className="w-full pl-12 pr-4 py-5 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-blue-500 transition-all font-bold text-sm"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>

                <button className="w-full py-5 bg-slate-900 text-white rounded-[2rem] font-black text-xs uppercase tracking-widest hover:bg-black transition-all flex items-center justify-center gap-3">
                  <RefreshCcw className="w-4 h-4" /> Reset Akun
                </button>

                <div className="text-center">
                  <button 
                    type="button"
                    onClick={() => setView('LOGIN')}
                    className="text-xs font-black text-slate-400 uppercase tracking-widest hover:text-slate-600"
                  >
                    Kembali ke Login
                  </button>
                </div>
              </form>
            )}

            <button 
              onClick={onCancel}
              className="w-full flex items-center justify-center gap-2 text-slate-400 hover:text-blue-600 text-[10px] font-black uppercase tracking-[0.2em] transition-all pt-8 border-t border-slate-100 mt-6"
            >
              <ArrowLeft className="w-4 h-4" /> Kembali ke Dashboard Kendaraan
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
