
import React, { useState } from 'react';
import { Search, MapPin, UserCheck, UserMinus, Filter, Download } from 'lucide-react';
import { PresenceStatus } from '../types';

const PresenceModule: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const handlePresenceAction = (status: PresenceStatus) => {
    setLoading(true);
    // Simulate API call and geolocation
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        alert(`${status === PresenceStatus.CHECK_IN ? 'Check-in' : 'Check-out'} Berhasil!\nLokasi: ${pos.coords.latitude}, ${pos.coords.longitude}`);
        setLoading(false);
      },
      (err) => {
        alert('Gagal mengambil lokasi. Pastikan izin GPS aktif.');
        setLoading(false);
      }
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-slate-800">Terminal Absensi Digital</h2>
          <p className="text-sm text-slate-500">Gunakan tombol di bawah untuk presensi harian</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => handlePresenceAction(PresenceStatus.CHECK_IN)}
            disabled={loading}
            className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 shadow-lg shadow-emerald-500/20 disabled:opacity-50 transition-all active:scale-95"
          >
            <UserCheck className="w-5 h-5" />
            CHECK IN
          </button>
          <button
            onClick={() => handlePresenceAction(PresenceStatus.CHECK_OUT)}
            disabled={loading}
            className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 disabled:opacity-50 transition-all active:scale-95"
          >
            <UserMinus className="w-5 h-5" />
            CHECK OUT
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 md:p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50/50">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Cari nama staf atau NIK..."
              className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all outline-none text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 text-slate-500 hover:bg-white rounded-lg border border-transparent hover:border-slate-200 transition-all">
              <Filter className="w-5 h-5" />
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors">
              <Download className="w-4 h-4" />
              Download Log
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/80 text-[10px] uppercase tracking-wider text-slate-500 font-bold">
                <th className="px-6 py-4">Staf</th>
                <th className="px-6 py-4">Waktu</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Lokasi</th>
                <th className="px-6 py-4">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[
                { name: 'Budi Santoso', role: 'Security Ops', time: '07:45:12', status: 'CHECK_IN', location: 'Gate A (HQ)' },
                { name: 'Siska Amelia', role: 'Staff HRD', time: '08:02:44', status: 'CHECK_IN', location: 'Gate A (HQ)' },
                { name: 'Rian Hidayat', role: 'Driver', time: '08:15:30', status: 'CHECK_IN', location: 'Gate B' },
                { name: 'Dewi Lestari', role: 'Supervisor', time: '17:05:01', status: 'CHECK_OUT', location: 'Gate A (HQ)' },
              ].map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-600">
                        {row.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-800">{row.name}</p>
                        <p className="text-[10px] text-slate-500">{row.role}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600 font-medium">{row.time}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      row.status === 'CHECK_IN' 
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' 
                        : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}>
                      {row.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                      <MapPin className="w-3 h-3 text-blue-500" />
                      {row.location}
                    </div>
                  </td>
                  <td className="px-6 py-4 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="text-blue-600 hover:underline text-xs font-bold">Details</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PresenceModule;
