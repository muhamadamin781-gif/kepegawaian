
import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Truck, 
  ShieldCheck, 
  Bell, 
  LogOut, 
  Menu, 
  X,
  History,
  FileText,
  UserCircle,
  LogIn,
  Settings,
  Briefcase,
  ClipboardList,
  FilePlus,
  Home,
  Package,
  Monitor,
  Clock
} from 'lucide-react';
import PublicVehicleDashboard from './components/PublicVehicleDashboard';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import PpnpnPresence from './components/PpnpnPresence';
import EmployeeProfile from './components/PnsProfile'; 
import EmployeeManagement from './components/EmployeeManagement';
import AttendanceReport from './components/AttendanceReport';
import VehicleModule from './components/VehicleModule';
import HouseholdModule from './components/HouseholdModule';
import SettingsModule from './components/SettingsModule';
import ProcurementModule from './components/ProcurementModule';
import { UserRole, User, ElectronicItem, ProcurementProposal, ProposalStatus } from './types';

const INITIAL_USERS: User[] = [
  { 
    id: 'admin-1', 
    name: 'M. Ali Firdaus (Admin)', 
    username: 'admin.kpknl', 
    password: '123', 
    email: 'admin@kpknl.go.id', 
    role: UserRole.ADMIN, 
    baseSalary: 7500000, 
    workHours: '07:30 - 17:00', 
    section: 'Bagian Umum' 
  },
  { 
    id: 'ksbu-1', 
    name: 'H. Suherman (Kasubag Umum)', 
    username: 'ksbu.kpknl', 
    password: '123', 
    email: 'ksbu@kpknl.go.id', 
    role: UserRole.KSBU, 
    baseSalary: 8500000, 
    workHours: '07:30 - 17:00', 
    section: 'Sub Bagian Umum' 
  },
  { 
    id: 'pns-1', 
    name: 'Siti Rohimah, S.H. (PNS)', 
    username: 'pns.kpknlserang', 
    password: '123', 
    email: 'pns@kpknl.go.id', 
    role: UserRole.PNS, 
    baseSalary: 6200000, 
    workHours: '07:30 - 17:00', 
    section: 'Seksi HI' 
  },
  { 
    id: 'satpam-1', 
    name: 'Supardi (Satpam)', 
    username: 'supardi.sec', 
    password: '123', 
    email: 'supardi@kpknl.go.id', 
    role: UserRole.SATPAM, 
    baseSalary: 4100000, 
    workHours: '12 Jam Shift', 
    section: 'Seksi Umum' 
  },
  { 
    id: 'pram-1', 
    name: 'Siska (Pramubakti)', 
    username: 'siska.pram', 
    password: '123', 
    email: 'siska@kpknl.go.id', 
    role: UserRole.PRAMUBAKTI,
    section: 'Seksi HI',
    workHours: '07:30 - 17:00'
  },
  { 
    id: 'driver-1', 
    name: 'Ahmad Faisal (Driver)', 
    username: 'ahmad.driver', 
    password: '123', 
    email: 'ahmad@kpknl.go.id', 
    role: UserRole.DRIVER, 
    section: 'Seksi Umum',
    workHours: 'Standby 24 Jam' 
  }
];

const INITIAL_PROPOSALS: ProcurementProposal[] = [
  { id: 'p1', userId: 'pns-1', userName: 'Siti Rohimah, S.H.', section: 'Seksi HI', itemProposed: 'Laptop Core i7 Gen 13', status: ProposalStatus.PROPOSED, date: '10/05/2024' },
  { id: 'p2', userId: 'satpam-1', userName: 'Supardi', section: 'Seksi Umum', itemProposed: 'Ban Mobil Innova (4 Unit)', status: ProposalStatus.PROCESSING, date: '12/05/2024' },
];

const INITIAL_ELECTRONICS: ElectronicItem[] = [
  { id: 'e1', itemName: 'Laptop Dell Latitude 5420', itemCode: 'EL-001/DJKN/2021', quantity: 1, personName: 'Siti Rohimah', section: 'Seksi HI' },
  { id: 'e2', itemName: 'Scanner Fujitsu ix1600', itemCode: 'EL-045/DJKN/2022', quantity: 1, personName: 'Ali Firdaus', section: 'Seksi Lelang' },
];

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [proposals, setProposals] = useState<ProcurementProposal[]>(INITIAL_PROPOSALS);
  const [electronicItems, setElectronicItems] = useState<ElectronicItem[]>(INITIAL_ELECTRONICS);
  const [activeTab, setActiveTab] = useState<string>('public');
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  const handleLogin = (u: User) => {
    const latestUser = users.find(usr => usr.username === u.username) || u;
    setCurrentUser(latestUser);
    setIsLoggedIn(true);
    if (latestUser.role === UserRole.ADMIN || latestUser.role === UserRole.KSBU) {
      setActiveTab('admin-dashboard');
    } else {
      setActiveTab('profile');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setActiveTab('public');
  };

  const handleUpdateUsers = (updatedUsers: User[]) => {
    setUsers(updatedUsers);
    if (currentUser) {
      const updatedSelf = updatedUsers.find(u => u.id === currentUser.id);
      if (updatedSelf) setCurrentUser(updatedSelf);
    }
  };

  const handleAddProposal = (newProposal: ProcurementProposal) => {
    setProposals([newProposal, ...proposals]);
  };

  const getNavItems = () => {
    if (!isLoggedIn) return [{ id: 'public', label: 'Dashboard Publik', icon: LayoutDashboard }];
    
    const items = [];
    const role = currentUser?.role;

    items.push({ id: 'profile', label: 'Profil Saya', icon: UserCircle });

    if (role === UserRole.ADMIN || role === UserRole.KSBU) {
      items.push(
        { id: 'admin-dashboard', label: 'Admin Panel', icon: LayoutDashboard },
        { id: 'management', label: 'Kepegawaian', icon: Users },
        { id: 'presensi-report', label: 'Laporan Presensi', icon: ClipboardList },
        { id: 'vehicle-mgmt', label: 'Kelola Kendaraan', icon: Truck },
        { id: 'household', label: 'Rumah Tangga', icon: Package },
        { id: 'procurement', label: 'Monitoring Usulan', icon: FilePlus },
        { id: 'settings', label: 'Pengaturan', icon: Settings }
      );
    } else if (role === UserRole.DRIVER) {
       items.push(
        { id: 'presence', label: 'Presensi', icon: ShieldCheck },
        { id: 'vehicle-mgmt', label: 'Maintance Kendaraan', icon: Truck },
        { id: 'history', label: 'Riwayat', icon: History }
      );
    } else if (role === UserRole.PRAMUBAKTI || role === UserRole.SATPAM || role === UserRole.CS) {
      items.push(
        { id: 'presence', label: 'Presensi Kehadiran', icon: ShieldCheck },
        { id: 'presensi-report', label: 'Dashboard Kehadiran', icon: ClipboardList },
        { id: 'monitoring-elektronik', label: 'Informasi Elektronik', icon: Monitor },
        { id: 'public', label: 'Ketersediaan Kendaraan', icon: Truck },
        { id: 'procurement', label: 'Usulan Pengadaan', icon: FilePlus }
      );
    } else if (role === UserRole.PNS) {
      items.push(
        { id: 'procurement', label: 'Usulan Pengadaan', icon: FilePlus },
        { id: 'monitoring-elektronik', label: 'Monitoring Elektronik', icon: Monitor },
        { id: 'history', label: 'Riwayat', icon: History }
      );
    }
    return items;
  };

  const renderContent = () => {
    if (activeTab === 'login') return (
      <Login 
        users={users} 
        onLogin={handleLogin} 
        onCancel={() => setActiveTab('public')} 
      />
    );
    if (activeTab === 'public') return <PublicVehicleDashboard />;
    
    switch (activeTab) {
      case 'profile': return (
        <EmployeeProfile 
          user={currentUser!} 
          onUpdateProfile={(updated) => {
            setCurrentUser(updated);
            setUsers(users.map(u => u.id === updated.id ? updated : u));
          }} 
        />
      );
      case 'admin-dashboard': return <AdminDashboard />;
      case 'management': return (
        <EmployeeManagement 
          users={users} 
          onUpdateUsers={handleUpdateUsers} 
          canEditWorkHours={currentUser?.role === UserRole.ADMIN || currentUser?.role === UserRole.KSBU} 
        />
      );
      case 'presensi-report': return (
        <AttendanceReport 
          isPersonalView={currentUser?.role !== UserRole.ADMIN && currentUser?.role !== UserRole.KSBU} 
          currentUserId={currentUser?.id} 
        />
      );
      case 'vehicle-mgmt': return <VehicleModule userRole={currentUser?.role} />;
      case 'household': return <HouseholdModule items={electronicItems} onUpdateItems={setElectronicItems} />;
      case 'procurement': return (
        <ProcurementModule 
          currentUser={currentUser!} 
          proposals={proposals} 
          onAddProposal={handleAddProposal} 
          isAdminView={currentUser?.role === UserRole.ADMIN || currentUser?.role === UserRole.KSBU} 
        />
      );
      case 'settings': return (
        <SettingsModule 
          currentUser={currentUser!} 
          users={users} 
          onUpdateUsers={handleUpdateUsers} 
          onUpdateSelf={(updated) => {
            setCurrentUser(updated);
            setUsers(users.map(u => u.id === updated.id ? updated : u));
          }}
        />
      );
      case 'monitoring-elektronik': return (
        <div className="space-y-6">
           <div className="bg-slate-900 rounded-[2.5rem] p-10 text-white relative overflow-hidden">
              <div className="absolute -right-10 -top-10 w-40 h-40 bg-blue-600/20 rounded-full blur-2xl"></div>
              <h2 className="text-3xl font-black italic tracking-tighter">Informasi Barang Elektronik</h2>
              <p className="text-slate-400 mt-2 font-medium">Data aset elektronik kantor yang tersinkronisasi secara real-time.</p>
           </div>
           <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 text-[10px] font-black uppercase tracking-widest text-slate-400">
                    <th className="px-8 py-6">Nama Barang</th>
                    <th className="px-8 py-6">Kode Barang</th>
                    <th className="px-8 py-6">Jumlah</th>
                    <th className="px-8 py-6">Nama / Seksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {electronicItems.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50/50 transition-all">
                      <td className="px-8 py-6 font-black text-slate-900 text-sm">{item.itemName}</td>
                      <td className="px-8 py-6 text-xs font-bold text-slate-500">{item.itemCode}</td>
                      <td className="px-8 py-6 text-sm font-black text-blue-600">{item.quantity} Unit</td>
                      <td className="px-8 py-6">
                        <p className="text-sm font-black text-slate-900">{item.personName}</p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.section}</p>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
           </div>
        </div>
      );
      case 'presence': return <PpnpnPresence user={currentUser!} />;
      default: return <div className="p-8 text-center text-slate-400 font-bold uppercase tracking-widest text-xs">Modul "{activeTab}" sedang dalam pengembangan.</div>;
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 font-sans">
      {isLoggedIn && (
        <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0`}>
          <div className="p-6 flex items-center gap-3 border-b border-slate-800">
            <div className="bg-blue-600 p-1.5 rounded-lg">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-black tracking-tighter italic uppercase">SATU KPKNL</span>
          </div>
          
          <nav className="mt-6 px-4 space-y-2 overflow-y-auto max-h-[calc(100vh-250px)]">
            {getNavItems().map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                  activeTab === item.id 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-semibold text-sm">{item.label}</span>
              </button>
            ))}
          </nav>

          <div className="absolute bottom-0 w-full p-4 border-t border-slate-800">
            <div className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-xl mb-4">
              <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center font-bold text-xs uppercase shadow-inner overflow-hidden text-white text-center">
                {currentUser?.photo ? <img src={currentUser.photo} className="w-full h-full object-cover" /> : currentUser?.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold truncate">{currentUser?.name}</p>
                <p className="text-[9px] text-slate-500 uppercase tracking-widest">{currentUser?.role.replace('_', ' ')}</p>
              </div>
            </div>
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors text-sm font-bold"
            >
              <LogOut className="w-5 h-5" />
              Keluar
            </button>
          </div>
        </aside>
      )}

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-6 sticky top-0 z-40">
          <div className="flex items-center gap-4">
            {isLoggedIn ? (
              <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-slate-100 rounded-lg md:hidden">
                {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <div className="bg-blue-600 p-1 rounded-md">
                  <Briefcase className="w-5 h-5 text-white" />
                </div>
                <span className="font-black text-slate-900 tracking-tighter italic">SATU KPKNL</span>
              </div>
            )}
            <h1 className="hidden sm:block text-sm font-black text-slate-800 uppercase tracking-widest ml-2">
              {getNavItems().find(i => i.id === activeTab)?.label || 'Internal App'}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            {!isLoggedIn && (
              <button onClick={() => setActiveTab('login')} className="flex items-center gap-2 px-5 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all active:scale-95">
                <LogIn className="w-4 h-4" /> Masuk Sistem
              </button>
            )}
            {isLoggedIn && (
              <div className="flex items-center gap-3">
                <button className="relative p-2.5 text-slate-400 hover:bg-slate-50 hover:text-blue-600 rounded-xl transition-all">
                  <Bell className="w-5 h-5" />
                  <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
                </button>
                <div className="w-8 h-8 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-xs text-slate-500 overflow-hidden text-white uppercase">
                   {currentUser?.photo ? <img src={currentUser.photo} className="w-full h-full object-cover" /> : currentUser?.name.charAt(0)}
                </div>
              </div>
            )}
          </div>
        </header>

        <section className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 scroll-smooth">
          {renderContent()}
        </section>
      </main>
    </div>
  );
};

export default App;
