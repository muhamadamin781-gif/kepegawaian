
export enum UserRole {
  ADMIN = 'ADMIN',
  PNS = 'PNS',
  KSBU = 'KSBU',
  SATPAM = 'SATPAM',
  DRIVER = 'DRIVER',
  PRAMUBAKTI = 'PRAMUBAKTI',
  CS = 'CLEANING_SERVICE'
}

export enum VehicleStatus {
  AVAILABLE = 'AVAILABLE',
  BORROWED = 'BORROWED',
  MAINTENANCE = 'MAINTENANCE'
}

export enum PresenceStatus {
  CHECK_IN = 'CHECK_IN',
  CHECK_OUT = 'CHECK_OUT'
}

export enum VehicleType {
  TRUCK = 'TRUCK',
  CAR = 'CAR',
  MOTORCYCLE = 'MOTORCYCLE'
}

export enum ProposalStatus {
  PROPOSED = 'DIUSULKAN',
  PROCESSING = 'PROSES',
  COMPLETED = 'SELESAI'
}

export interface ProcurementProposal {
  id: string;
  userId: string;
  userName: string;
  section: string;
  itemProposed: string;
  attachment?: string;
  status: ProposalStatus;
  date: string;
}

export interface MaintenanceInfo {
  senderName: string;
  workshopName: string;
  workshopAddress: string;
  repairedItems?: string;
}

export interface TrainingRecord {
  id: string;
  name: string;
  date: string;
  hours: string;
  certificateUrl?: string;
}

export interface SalaryHistory {
  id: string;
  description: string;
  effectiveDate: string;
  amount: number;
}

export interface User {
  id: string;
  nip?: string;
  username: string;
  password?: string;
  name: string;
  role: UserRole;
  section?: string;
  baseSalary?: number;
  workHours?: string;
  address?: string;
  education?: string;
  phone?: string;
  photo?: string;
  email?: string;
  trainingHistory?: TrainingRecord[];
  salaryHistory?: SalaryHistory[];
  nextSalaryIncrease?: string;
}

export interface Vehicle {
  id: string;
  name: string;
  plateNumber: string;
  type: VehicleType;
  status: VehicleStatus;
  category: 'OPERATIONAL' | 'HEAD_OFFICE';
  photo?: string;
  borrower?: string;
  section?: string;
  purpose?: string;
  timeRange?: string;
  maintenanceInfo?: MaintenanceInfo;
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  role: UserRole;
  date: string;
  checkIn: string;
  checkOut: string;
  lateMinutes: number;
  status: 'Hadir' | 'Terlambat' | 'Izin' | 'Sakit';
}

export interface ElectronicItem {
  id: string;
  itemName: string;
  itemCode: string;
  quantity: number;
  personName: string;
  section: string;
}
